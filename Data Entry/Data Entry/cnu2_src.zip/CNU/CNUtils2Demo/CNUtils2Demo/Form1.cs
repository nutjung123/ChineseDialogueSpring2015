//---------------------------------------------------------------------------------
//Form1.cs - version 1.0.0.1rc
// C# version of MIT's ConceptNet 2.1 
//WHAT'S NEW: 
//      -Some tests for some new CTools methods
//TO DO:
//      -
//
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
//Copyright (c) 2006 by Joseph P. Socoloski III
//LICENSE
//If it is your intent to use this software for non-commercial purposes, 
//such as in academic research, this software is free and is covered under 
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
//---------------------------------------------------------------------------------
#region Namespaces
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Timers;

using ConceptNetUtils;
using ConceptNetUtils.Forms;
using ConceptNetUtils.IPEWrapper;
using ConceptNetUtils.Paths;

using IronPython.Compiler;
using IronPython.Hosting;
using IronPython.Modules;
using IronPython.Runtime;
using IronPython.CodeDom;
using IronPython.Runtime.Types;
using IronPython.Runtime.Exceptions;
using IronPython.Runtime.Calls;
using IronPython.Compiler.Generation;
using IronPython.Runtime.Operations;

using System.IO;
#endregion Namespaces

namespace CNUtilsDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region IronPython Prep and helper methods
        /// <summary>
        /// Method that allows capture of IronPython output
        /// </summary>
        /// <param name="text"></param>
        void IPEtbResponse(string text)
        {
            if (!string.IsNullOrEmpty(text.Trim()))
            {
                text = text.Replace("\\n", "\r\n");
                tbOutput.AppendText(text + Environment.NewLine);
                tbOutput.Update();
            }
        }
        #endregion IronPython Prep and helper methods

        #region Form Load
        private void Form1_Load(object sender, EventArgs e)
        {
            //Display the form
            this.Show();
            this.Update();

            //Must set & override the paths to ConceptNet install.
            //They are found in CNUDB and CNUMontylingua.py
            ConceptNetUtils.CNDB.ConceptNet21path = ConceptNetUtils.Paths.MiscDirs.ConceptNet;
            //Associate the main IronPython.Runtime.PythonEngine with IPEStreamWrapper
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));
            //Start ConceptNet/MontyLingua and create the semantic network from the predicate files
            ConceptNetUtils.CNDB.Initialize();
        }
        #endregion Form Load

        #region Click Events

        #region Single words
        /// <summary>
        /// Returns the "pretty print" of a node's contents.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        private void btBrowse_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Create SymbolId
            IronPython.Runtime.SymbolId textnode_list_SymbolId = (SymbolId)"textnode_list";
            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["textnode_list"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("c.display_node(textnode_list.encode('ascii','strict'))");
                }
                catch (Exception ex)
                {
                  MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;
        }

        /// <summary>
        /// Returns list of default weighted context for a node.
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        private void btContext_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["textnode_list"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n'.join(map(lambda z:z[0]+' ('+str(int(z[1]*100))+'%)', c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')))))");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                    
                    //Ops.ExtractException(ex, Ops);
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;
        }

        /// <summary>
        /// inputs a list of concepts computes all available contextual projections
        /// and returns a list of pairs, each of the form:
        ///  ('ProjectionName',
        ///        (('concept1',score1), ('concept2,score2), ...))
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        private void btProjection_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["textnode_list"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n\n'.join(map(lambda v:v[0].upper()+'\n'+'\n'.join(map(lambda z:z[0]+' ('+str(int(z[1]*100))+'%)',v[1])[:10]), c.get_all_projections(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')))))");      
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;        
        }
         
        /// <summary>
        /// -inputs a node and uses structure-mapping to generate a list of analogous concepts
        /// -each analogous concept shares some structural features with the input node
        /// -the strength of an analogy is determined by the number
        /// and weights of each feature. a weighting scheme is used
        /// to disproportionately weight different relation types
        /// and also weights a structural feature by the equation:
        /// math.log(f+f2+0.5*(i+i2)+2,4), where f= i =
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        private void btAnalogy_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["textnode_list"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n\n'.join(map(lambda match:'[~'+match[0]+'] ('+str(match[2])+')\n  '+'\n  '.join(map(lambda struct:'=='+struct[0]+'==> '+struct[1]+' ('+str(struct[2])+') ',match[1])),c.get_analogous_concepts(textnode_list.encode('ascii','strict').strip())))");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;
        }
        #endregion Single words

        #region Sentences
        private void btGuessConcept_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["text"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n\n'.join(map(lambda match:'[is it: '+match[0]+'?] ('+str(match[2])+')\n  '+'\n  '.join(map(lambda struct:'=='+struct[0]+'==> '+struct[1]+' ('+str(struct[2])+') ',match[1])),c.nltools.guess_concept(text.encode('ascii','strict').strip())))");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;
        }

        private void btGuessTopic_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["in_text"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n'.join(map(lambda z:z[0]+' ('+str(int(z[1]*100))+'%)',c.nltools.guess_topic(in_text.encode('ascii','strict').strip())[1]))");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;   
        }

        private void btGuessMood_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["text"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"'\n'.join(map(lambda z:z[0]+' ('+str(int(z[1]*100))+'%)',c.nltools.guess_mood(text.encode('ascii','strict').strip()))) +'\n\n'");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;   
        }

        private void btSummarize_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            tbOutput.Clear();

            //Set the output to the Textbox
            ConceptNetUtils.CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEtbResponse));

            //Print the value of the variable in the python code
            ConceptNetUtils.CNDB.cn_pe.Globals["text"] = tbText.Text.Trim();

            if (tbText.Text != "")
            {
                try
                {
                    ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole(@"c.nltools.summarize_document(text.encode('ascii','strict').strip())");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConceptNetUtils.CNDB.cn_pe.FormatException(ex));
                }
            }
            else
                MessageBox.Show("Please enter a word, sentence, or paragraph.");
            Cursor.Current = Cursors.Default;
        }
        #endregion Sentences

        private void btTest_Click(object sender, EventArgs e)
        {
            Dict myDict = new Dict();
            IronPython.Runtime.List myList = new IronPython.Runtime.List();
            Tuple t_main = new Tuple();
            //myList = ConceptNetUtils.Monty.MontyLingua.jist(tbText.Text.Trim());
            //myList = ConceptNetUtils.Monty.MontyLingua.jist_predicates(tbText.Text.Trim());
            //myList = ConceptNetUtils.Monty.MontyLingua.split_paragraphs(tbText.Text.Trim());
            //myList = ConceptNetUtils.Monty.MontyLingua.split_sentences(tbText.Text.Trim());
            //t_main = (Tuple)ConceptNetUtils.CNTools.guess_topic(tbText.Text.Trim())[1];
            myList = (List)ConceptNetUtils.CNTools.guess_topic(tbText.Text.Trim())[1];

            //myList = (List)t_main.GetEnumerator().Current;
            //Tuple t_first = (Tuple)myList.Pop(0);
            //string topic = t_first[0].ToString();

            IronPython.Runtime.List myList2 = new IronPython.Runtime.List();
            myList2 = Converts.Convert_CodeStringtoIPList(myList.ToCodeString());

            #region commented
            //Tuple myTuple = new Tuple();
            //myTuple = ConceptNetUtils.CNDB.get_analogous_concepts(tbText.Text.Trim(), 0);

            //Converts.MessageBoxIronPy(ConceptNetUtils.CNDB.get_context(tbText.Text.Trim()));

            //ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("t.tag('" + tbText.Text.Trim() +"')");

            //myList = ConceptNetUtils.CNDB.project_consequences(tbText.Text.Trim());
            
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("fw={}");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("fw=c.fw_edges");
            ///myDict = (Dict)ConceptNetUtils.CNDB.cn_pe.Globals["fw"];
            ///File.WriteAllText(Application.StartupPath + "\\mydict.txt", myDict.ToCodeString());
            //myDict = Converts.Convert_StringtoDict(File.ReadAllText(Application.StartupPath + "\\mydict.txt"));

            ///CNDB.cn_pe.Globals["myfile"] = Application.StartupPath + "\\fw_edges.txt";
            ///CNDB.cn_pe.Import("pickle");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("output =open(myfile, 'wb')");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("pickle.dump(c.fw_edges,output, protocol=2)");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("output.close()");

            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("input = open(myfile, 'rb')");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("new_dict = pickle.load(input)");
            ///ConceptNetUtils.CNDB.cn_pe.ExecuteToConsole("input.close()");
            ///myDict = (Dict)ConceptNetUtils.CNDB.cn_pe.Globals["new_dict"];



            //string temp = ConceptNetUtils.CNDB.display_node(tbText.Text.Trim());

            //Dict linktype_weights_dict2 = new Dict();
            //linktype_weights_dict2.Add("DesireOf", 1.0);
            //linktype_weights_dict2.Add("DesirousEffectOf", 1.0);
            //linktype_weights_dict2.Add("MotivationOf", 1.0);
            //myList = ConceptNetUtils.CNDB.get_context(tbText.Text.Trim(), 500, 200, 300, linktype_weights_dict2, 0);
            //myList = ConceptNetUtils.CNDB.get_context(tbText.Text.Trim(), 200, 100, 200);

            //string temp = ConceptNetUtils.CNDB.load_predicates_file("E:\\CNU\\machine_All.txt");
            //string temp = ConceptNetUtils.CNDB.pp_predicate("(ConceptuallyRelatedTo \"machine\" \"coin slot\" \"f=2;i=0;\")");
            
            //Tuple temp2 =new Tuple();
            //temp2 = ConceptNetUtils.CNDB.unpp("(ConceptuallyRelatedTo \"machine\" \"coin slot\" \"f=2;i=0;\")");
            //string temp = ConceptNetUtils.CNTools.chunk(tbText.Text.Trim());

            //string temp = ConceptNetUtils.CNTools.tag(tbText.Text.Trim());
            //myList = ConceptNetUtils.CNTools.generate_extraction(tbText.Text.Trim());
            //Converts.MessageBoxIronPy(ConceptNetUtils.Monty.Monty.jist_predicates(tbText.Text.Trim()));

            //tbOutput.AppendText(temp);
            #endregion commented
        }

        #endregion Click Events

        #region misc Notes
        //import pdb; pdb.set_trace()  //place this in Python script to trace in IDLE

        //IDLE is Python's Tkinter-based Integrated DeveLopment Environment. http://www.python.org/idle/
        //Converts.MessageBoxIronPy(ConceptNetUtils.CNDB.cn_pe.GetGlobal(textnode_list_SymbolId));
        #endregion misc Notes
    }
}