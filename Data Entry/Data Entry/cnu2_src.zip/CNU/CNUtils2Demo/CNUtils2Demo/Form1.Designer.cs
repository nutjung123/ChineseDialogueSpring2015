namespace CNUtilsDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbText = new System.Windows.Forms.TextBox();
            this.gbText_Input = new System.Windows.Forms.GroupBox();
            this.btBrowse = new System.Windows.Forms.Button();
            this.btContext = new System.Windows.Forms.Button();
            this.tbOutput = new System.Windows.Forms.TextBox();
            this.btProjection = new System.Windows.Forms.Button();
            this.btAnalogy = new System.Windows.Forms.Button();
            this.btGuessTopic = new System.Windows.Forms.Button();
            this.btGuessMood = new System.Windows.Forms.Button();
            this.btSummarize = new System.Windows.Forms.Button();
            this.btGuessConcept = new System.Windows.Forms.Button();
            this.btTest = new System.Windows.Forms.Button();
            this.gbText_Input.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbText
            // 
            this.tbText.BackColor = System.Drawing.SystemColors.Window;
            this.tbText.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbText.Location = new System.Drawing.Point(6, 21);
            this.tbText.MaxLength = 992767;
            this.tbText.Multiline = true;
            this.tbText.Name = "tbText";
            this.tbText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbText.Size = new System.Drawing.Size(579, 64);
            this.tbText.TabIndex = 0;
            // 
            // gbText_Input
            // 
            this.gbText_Input.Controls.Add(this.tbText);
            this.gbText_Input.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbText_Input.Location = new System.Drawing.Point(12, 12);
            this.gbText_Input.Name = "gbText_Input";
            this.gbText_Input.Size = new System.Drawing.Size(591, 94);
            this.gbText_Input.TabIndex = 33;
            this.gbText_Input.TabStop = false;
            this.gbText_Input.Text = "Enter a word, sentence, or paragraph.";
            // 
            // btBrowse
            // 
            this.btBrowse.BackColor = System.Drawing.Color.YellowGreen;
            this.btBrowse.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btBrowse.Location = new System.Drawing.Point(13, 112);
            this.btBrowse.Name = "btBrowse";
            this.btBrowse.Size = new System.Drawing.Size(75, 23);
            this.btBrowse.TabIndex = 0;
            this.btBrowse.Text = "BROWSE";
            this.btBrowse.UseVisualStyleBackColor = false;
            this.btBrowse.Click += new System.EventHandler(this.btBrowse_Click);
            // 
            // btContext
            // 
            this.btContext.BackColor = System.Drawing.Color.YellowGreen;
            this.btContext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btContext.Location = new System.Drawing.Point(94, 112);
            this.btContext.Name = "btContext";
            this.btContext.Size = new System.Drawing.Size(75, 23);
            this.btContext.TabIndex = 1;
            this.btContext.Text = "CONTEXT";
            this.btContext.UseVisualStyleBackColor = false;
            this.btContext.Click += new System.EventHandler(this.btContext_Click);
            // 
            // tbOutput
            // 
            this.tbOutput.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOutput.Location = new System.Drawing.Point(12, 173);
            this.tbOutput.MaxLength = 992767;
            this.tbOutput.Multiline = true;
            this.tbOutput.Name = "tbOutput";
            this.tbOutput.ReadOnly = true;
            this.tbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOutput.Size = new System.Drawing.Size(591, 319);
            this.tbOutput.TabIndex = 33;
            // 
            // btProjection
            // 
            this.btProjection.BackColor = System.Drawing.Color.YellowGreen;
            this.btProjection.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btProjection.Location = new System.Drawing.Point(175, 112);
            this.btProjection.Name = "btProjection";
            this.btProjection.Size = new System.Drawing.Size(95, 23);
            this.btProjection.TabIndex = 34;
            this.btProjection.Text = "PROJECTION";
            this.btProjection.UseVisualStyleBackColor = false;
            this.btProjection.Click += new System.EventHandler(this.btProjection_Click);
            // 
            // btAnalogy
            // 
            this.btAnalogy.BackColor = System.Drawing.Color.YellowGreen;
            this.btAnalogy.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAnalogy.Location = new System.Drawing.Point(276, 112);
            this.btAnalogy.Name = "btAnalogy";
            this.btAnalogy.Size = new System.Drawing.Size(74, 23);
            this.btAnalogy.TabIndex = 35;
            this.btAnalogy.Text = "ANALOGY";
            this.btAnalogy.UseVisualStyleBackColor = false;
            this.btAnalogy.Click += new System.EventHandler(this.btAnalogy_Click);
            // 
            // btGuessTopic
            // 
            this.btGuessTopic.BackColor = System.Drawing.Color.Yellow;
            this.btGuessTopic.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuessTopic.Location = new System.Drawing.Point(276, 144);
            this.btGuessTopic.Name = "btGuessTopic";
            this.btGuessTopic.Size = new System.Drawing.Size(100, 23);
            this.btGuessTopic.TabIndex = 36;
            this.btGuessTopic.Text = "GUESS TOPIC";
            this.btGuessTopic.UseVisualStyleBackColor = false;
            this.btGuessTopic.Click += new System.EventHandler(this.btGuessTopic_Click);
            // 
            // btGuessMood
            // 
            this.btGuessMood.BackColor = System.Drawing.Color.Yellow;
            this.btGuessMood.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuessMood.Location = new System.Drawing.Point(382, 144);
            this.btGuessMood.Name = "btGuessMood";
            this.btGuessMood.Size = new System.Drawing.Size(100, 23);
            this.btGuessMood.TabIndex = 37;
            this.btGuessMood.Text = "GUESS MOOD";
            this.btGuessMood.UseVisualStyleBackColor = false;
            this.btGuessMood.Click += new System.EventHandler(this.btGuessMood_Click);
            // 
            // btSummarize
            // 
            this.btSummarize.BackColor = System.Drawing.Color.Yellow;
            this.btSummarize.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSummarize.Location = new System.Drawing.Point(488, 144);
            this.btSummarize.Name = "btSummarize";
            this.btSummarize.Size = new System.Drawing.Size(100, 23);
            this.btSummarize.TabIndex = 38;
            this.btSummarize.Text = "SUMMARIZE";
            this.btSummarize.UseVisualStyleBackColor = false;
            this.btSummarize.Click += new System.EventHandler(this.btSummarize_Click);
            // 
            // btGuessConcept
            // 
            this.btGuessConcept.BackColor = System.Drawing.Color.Yellow;
            this.btGuessConcept.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuessConcept.Location = new System.Drawing.Point(147, 144);
            this.btGuessConcept.Name = "btGuessConcept";
            this.btGuessConcept.Size = new System.Drawing.Size(123, 23);
            this.btGuessConcept.TabIndex = 39;
            this.btGuessConcept.Text = "GUESS CONCEPT";
            this.btGuessConcept.UseVisualStyleBackColor = false;
            this.btGuessConcept.Click += new System.EventHandler(this.btGuessConcept_Click);
            // 
            // btTest
            // 
            this.btTest.Location = new System.Drawing.Point(32, 144);
            this.btTest.Name = "btTest";
            this.btTest.Size = new System.Drawing.Size(75, 23);
            this.btTest.TabIndex = 40;
            this.btTest.Text = "Test";
            this.btTest.UseVisualStyleBackColor = true;
            this.btTest.Click += new System.EventHandler(this.btTest_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 504);
            this.Controls.Add(this.btTest);
            this.Controls.Add(this.btGuessConcept);
            this.Controls.Add(this.btSummarize);
            this.Controls.Add(this.btGuessMood);
            this.Controls.Add(this.btGuessTopic);
            this.Controls.Add(this.btAnalogy);
            this.Controls.Add(this.btProjection);
            this.Controls.Add(this.tbOutput);
            this.Controls.Add(this.btContext);
            this.Controls.Add(this.btBrowse);
            this.Controls.Add(this.gbText_Input);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ConceptNet Utilities (CNU) C# v2.7. Demo Mini-Browser";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbText_Input.ResumeLayout(false);
            this.gbText_Input.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbText;
        private System.Windows.Forms.GroupBox gbText_Input;
        private System.Windows.Forms.Button btBrowse;
        private System.Windows.Forms.Button btContext;
        private System.Windows.Forms.TextBox tbOutput;
        private System.Windows.Forms.Button btProjection;
        private System.Windows.Forms.Button btAnalogy;
        private System.Windows.Forms.Button btGuessTopic;
        private System.Windows.Forms.Button btGuessMood;
        private System.Windows.Forms.Button btSummarize;
        private System.Windows.Forms.Button btGuessConcept;
        private System.Windows.Forms.Button btTest;
    }
}

