//------------------------------------------------------------------------------
//PersonalizedFileForm.cs - version 0.02172006.0rc1
//To Do:  
//
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
//Copyright (c) 2006 by Joseph P. Socoloski III
//LICENSE
//If it is your intent to use this software for non-commercial purposes, 
//such as in academic research, this software is free and is covered under 
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
//------------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Xml.Serialization;
using ConceptNetUtils;

namespace ConceptNetUtils
{
    namespace Forms
    {
        /// <summary>
        /// 
        /// </summary>
        public partial class PersonalizedFileForm : Form
        {
            /// <summary>
            /// 
            /// </summary>
            public string textfilename;
            /// <summary>
            /// 
            /// </summary>
            public string wordphrase1;
            /// <summary>
            /// 
            /// </summary>
            public string filename_chk1, filename_chk2;
            ArrayList nodesinfile = new ArrayList();
            ToolTip toolTip1 = new ToolTip();
            //ConceptNetUtils.Misc CNMisc = new ConceptNetUtils.Misc();

            /// <summary>
            /// 
            /// </summary>
            public PersonalizedFileForm()
            {
                InitializeComponent();
            }

            /// <summary>
            /// Takes in any information needed to start the form.
            /// </summary>
            /// <param name="fullfilename">Path and filename.</param>
            /// <param name="word1">String to save to the file.</param>
            /// <param name="listin">Set "true" to overwite existing files.</param>
            public void Initialize(string fullfilename, string word1, ArrayList listin)
            {
                if (File.Exists(textfilename) != false)
                {
                    //Make sure the textbox is containing a filename
                    if (fullfilename.Length > 0 && fullfilename.IndexOf(".txt") != -1)
                    {
                        //Fill the textboxes with the incoming data from the calling method
                        tbFilename.Text = fullfilename;
                        tbWord1.Text = word1;

                        //Assign the global class variables
                        textfilename = fullfilename;
                        wordphrase1 = word1;
                    }
                    else
                        MessageBox.Show("Error: The filename passed does not seem to be a valid text file path.");
                }

            }

            /// <summary>
            /// Load.
            /// </summary>
            private void PersonalizedFileForm_Load(object sender, EventArgs e)
            {
                // Set up the delays for the ToolTip.
                toolTip1.AutoPopDelay = 1000;
                toolTip1.InitialDelay = 100;
                toolTip1.ReshowDelay = 100;
                // Force the ToolTip text to be displayed whether or not the form is active.
                toolTip1.ShowAlways = true;

                if (textfilename != "")
                {
                    chkbFile1.Checked = true;
                    chkNewFile.Checked = false;
                    tbFilename.Enabled = false;
                    tbFilename.Text = textfilename;
                    tbFilename.SelectionStart = tbFilename.Text.Length;

                    // Set up the ToolTip text for the Button and Checkbox.
                    toolTip1.SetToolTip(this.chkbFile1, textfilename);
                    toolTip1.SetToolTip(this.btBrowseFile1, textfilename);
                    toolTip1.SetToolTip(this.chkNewFile, "");
                    filename_chk1 = textfilename;

                    Displaytextfile();
                }
                else
                {
                    //Make sure only one checkbox is checked
                    chkbFile1.Checked = false;
                    chkNewFile.Checked = true;
                    tbFilename.Enabled = true;
                    tbFilename.Text = "";
                    // Set up the ToolTip text for the Button and Checkbox.
                    toolTip1.SetToolTip(this.chkbFile1, textfilename);
                    toolTip1.SetToolTip(this.btBrowseFile1, textfilename);
                    toolTip1.SetToolTip(this.chkNewFile, tbFilename.Text);
                    filename_chk2 = tbFilename.Text;
                }

                //Select the "IsA" item in the Relationship Types ComboBox DropDownList
                cbRelationshipTypes.SelectedIndex = 4;
            }

            /// <summary>
            /// Displays variable: "textfilename" contents to txtDisplay
            /// </summary>
            private void Displaytextfile()
            {
                txtDisplay.Clear();
                if (textfilename != null && File.Exists(textfilename) != false)
                {
                    if (textfilename != "" && textfilename != "" && textfilename.IndexOf(".txt") != -1)
                        txtDisplay.AppendText(File.ReadAllText(textfilename));
                    else
                        txtDisplay.Text = "";
                }
            }

            /// <summary>
            /// Browses to an existing textfile and then displays it in txtDisplay.
            /// </summary>
            private void btBrowseFile1_Click(object sender, EventArgs e)
            {
                System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
                ofd.InitialDirectory = Application.StartupPath;
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    textfilename = ofd.FileName;
                    chkbFile1.Text = textfilename;
                    chkbFile1.Update();
                }

                chkbFile1.Checked = true;
                chkNewFile.Checked = false;
                tbFilename.Enabled = false;
                tbFilename.Text = textfilename;
                tbFilename.SelectionStart = tbFilename.Text.Length;
                filename_chk1 = textfilename;

                Displaytextfile();
            }

            /// <summary>
            /// On chkbFile1_Click, if pointing to an existing textfile it then displays it in txtDisplay.
            /// </summary>
            private void chkbFile1_Click(object sender, EventArgs e)
            {
                textfilename = filename_chk1;
                chkbFile1.Checked = true;
                chkNewFile.Checked = false;
                tbFilename.Enabled = false;

                tbFilename.Text = textfilename;
                tbFilename.SelectionStart = tbFilename.Text.Length;
                filename_chk1 = textfilename;

                Displaytextfile();
            }

            /// <summary>
            /// On chkNewFile_Click, if pointing to an existing textfile it then displays it in txtDisplay.
            /// </summary>
            private void chkNewFile_Click(object sender, EventArgs e)
            {
                textfilename = filename_chk2;

                chkbFile1.Checked = false;
                chkNewFile.Checked = true;
                tbFilename.Enabled = true;

                tbFilename.Text = Application.StartupPath;
                tbFilename.SelectionStart = tbFilename.Text.Length;
                toolTip1.SetToolTip(this.chkNewFile, tbFilename.Text);
                textfilename = tbFilename.Text.Trim();
                filename_chk2 = textfilename;

                Displaytextfile();
            }

            /// <summary>
            /// Add predicate node to an existing textfile it then displays it in txtDisplay.
            /// </summary>
            public void btAdd_Click(object sender, System.EventArgs e)
            {
                string newCNLine = "";
                tbWord1.Text = tbWord1.Text.ToLower();
                tbComplement.Text = tbComplement.Text.ToLower();

                //Update textfilename var with 
                textfilename = tbFilename.Text.Trim();

                if (Validate_txt() != false)
                {
                    //if both one checked and filename is valid
                    if (tbWord1.Text != "" && tbComplement.Text != "")
                    {
                        newCNLine = CNMisc.Create_CNLine(CNMisc.RemoveCategoryString(cbRelationshipTypes.Text), tbWord1.Text, tbComplement.Text, 0, 0);
                        CNMisc.AddLine(textfilename, newCNLine);
                        tbComplement.Text = "";

                        Displaytextfile();
                    }
                    else
                        MessageBox.Show("You must enter a word and complement to add a line to your choosen file.");
                }
            }

            private void btClose_Click(object sender, EventArgs e)
            {
                this.Close();
            }

            private void tbFilename_TextChanged(object sender, EventArgs e)
            {
                if (chkNewFile.Checked == true)
                    toolTip1.SetToolTip(this.chkNewFile, tbFilename.Text);

                filename_chk2 = tbFilename.Text;
            }

            private void tbFilename_Leave(object sender, EventArgs e)
            {
                Validate_txt();
            }

            private bool Validate_txt()
            {
                bool isValidfile = true;

                if (tbFilename.Text.IndexOf(".txt") == -1 && chkbFile1.Focused == false && btClose.Focused == false && btBrowseFile1.Focused == false)
                {
                    MessageBox.Show("Error: The filename you entered does not seem to be a valid text file path.\r\nPlease correct by adding the prefix .txt to your filename.");
                    tbFilename.Focus();
                    tbFilename.SelectionStart = tbFilename.Text.Length;
                    isValidfile = false;
                }

                return isValidfile;
            }
        }
    }
}