import sys,math,time
import CNUTools
from CNUTools import ConceptNetNLTools
__version__ = "2.1"
__author__	  = "hugo@media.mit.edu modified by Joseph P. Socoloski III July 10, 2006"
__modified__  = "modified by Joseph P. Socoloski III July 10, 2006"
__modified2__ = "for development of ConceptNet Utilities (CNU) a C# library"
__url__ = 'www.conceptnet.org'
class ConceptNetDB:
    conceptnet21Dir = 'C:\Documents and Settings\Joseph\My Documents\Python Projects\conceptnet2.1'
    theconfig_filename = conceptnet21Dir + '\ConceptNet.ini'

    def __init__(self,ConceptNetNLTools_handle=None,config_filename=theconfig_filename):
        print '\n********** ConceptNet v.'+__version__+' **********'
        print '***** '+__modified__+' *****'
        print '***** '+__modified2__+' ******'
        config_lines=open(config_filename,'r').read().split('\n')
        config_lines = filter(lambda x:(';' not in x) and ('=' in x),config_lines)
        files_to_load = map(lambda z:z[0],filter(lambda y:y[1].lower().strip()=='yes',map(lambda x:x.split('='),config_lines)))
        self.predicates_filenames = files_to_load
        self.word_hash,self.node_hash,self.edge_hash = {},{},{}
        self.word_lookup,self.node_lookup,self.edge_lookup = {},{},{}
        self.fw_edges,self.bw_edges = {},{}
        self.global_uid = 0
        print 'Loading Natural Language Component...'
        if not ConceptNetNLTools_handle:
            self.nltools = CNUTools.ConceptNetNLTools(self)
        else:
            self.nltools = ConceptNetNLTools_handle
        print 'Loading Common Sense Component...\n'
        time1=time.clock()
        self.load_predicates()
        time2=time.clock()
        print "-- took",str(round(time2-time1,6)),'seconds. --\n'
        print 'Performing Optimizations...\n'
        self.optimize_order()
        print '**************************************\n'
        
    def get_analogous_concepts(self,textnode,simple_results_p=0):

        """
        -inputs a node
        -uses structure-mapping to generate a list of
        analogous concepts
        -each analogous concept shares some structural features
        with the input node
        -the strength of an analogy is determined by the number
        and weights of each feature. a weighting scheme is used
        to disproportionately weight different relation types
        and also weights a structural feature by the equation:
        math.log(f+f2+0.5*(i+i2)+2,4), where f=
        i =
        - outputs a list of RESULTs rank-ordered by relevance
        - each RESULT is a triple of the form:
                     ('analogous concept', SHARED_STRUCTURES, SCORE)
        - SCORE is a scalar valuation of quality of a result
          (for now, this number does not have much external meaning)
        - SHARED_STRUCTURES is a list of triples, each of the form:
                     ('RelationType', 'target node', SCORE2)
        - SCORE2 is a scalar valuation of the strength of a
        particular shared structure
        - if simple_results_p = 1, then output object is simply
        a list of rank-ordered concepts
      """
        decode_node,encode_node,encode_word,decode_word = self.decode_node,self.encode_node,self.encode_word,self.decode_word
        zipped2nodeuid,nodeuid2zipped = self.zipped2nodeuid, self.nodeuid2zipped
        zipped2edgeuid,edgeuid2zipped = self.zipped2edgeuid, self.edgeuid2zipped
        fw_edges,bw_edges = self.fw_edges,self.bw_edges
        linktype_stoplist = ['ConceptuallyRelatedTo','ThematicKLine','SuperThematicKline']
        linktype_stoplist = map(encode_word,linktype_stoplist)
        linktype_weights = {'PropertyOf':3.0,
                            'UsedFor':2.0,
                            'CapableOf':2.0,
                            'CapableOfReceivingAction':1.5}
        textnode=textnode.strip()
        encoded_node = encode_node(textnode)
        node_uid = zipped2nodeuid(encoded_node)
        fes = fw_edges.get(node_uid,[])
        fes = map(edgeuid2zipped,fes)
        candidates = {}
        for fe in fes:
            commonpred,commonnode,f,i = fe
            if commonpred in linktype_stoplist:
                continue
            bes = bw_edges.get(commonnode,[])
            bes = map(edgeuid2zipped,bes)
            bes = filter(lambda x:x[0]==commonpred and x[1]!=node_uid,bes)
            for be in bes:
                commonpred2,candidate,f2,i2 = be
                link_strength = math.log(f+f2+0.5*(i+i2)+2,4)
                weight = link_strength*linktype_weights.get(decode_word(commonpred),1.0)
                candidates[candidate] = candidates.get(candidate,[])+[(commonpred,commonnode,weight)]
        scored_candidates = map(lambda x:(x[0],x[1],sum(map(lambda y:y[2],x[1]))),candidates.items())
        scored_candidates.sort(lambda x,y:int(1000*(y[2]-x[2])))
        scored_candidates = map(lambda y:(decode_node(nodeuid2zipped(y[0])),map(lambda x:(decode_word(x[0]),decode_node(nodeuid2zipped(x[1])),weight),y[1]),y[2]),scored_candidates)
        if simple_results_p:
            return map(lambda x:x[0],scored_candidates)
        return scored_candidates
    def get_all_projections(self,textnode_list):

        """
        inputs a list of concepts
        computes all available contextual projections
        and returns a list of pairs, each of the form:
             ('ProjectionName',
                (('concept1',score1), ('concept2,score2), ...)
             )
      """
        output = []
        output += [('Consequences',self.project_consequences(textnode_list))]
        output += [('Details',self.project_details(textnode_list))]
        output += [('Spatial',self.project_spatial(textnode_list))]
        output += [('Affective',self.project_affective(textnode_list))]
        return output
    def project_affective(self,textnode_list):

        """
        -inputs a list of concepts
        -computes the affective projection, which is
        the emotional context and consequences underlying these concepts
        -returns a rank-ordered list of concepts and their scores
        e.g.: (('concept1',score1), ('concept2,score2), ...)
      """
        linktype_weights_dict = {
            'DesireOf':1.0,
            'DesirousEffectOf':1.0,
            'MotivationOf':1.0,
            }
        return self.get_context(textnode_list,linktype_weights_dict=linktype_weights_dict)
    def project_spatial(self,textnode_list):

        """
        -inputs a list of concepts
        -computes the spatial projection, which consists of
        relevant locations, relevant objects in the same scene.
        -returns a rank-ordered list of concepts and their scores
        e.g.: (('concept1',score1), ('concept2,score2), ...)
      """
        linktype_weights_dict = {
            'LocationOf':1.0,
            'ThematicKLine':0.5,
            }
        return self.get_context(textnode_list,linktype_weights_dict=linktype_weights_dict)
    def project_details(self,textnode_list):

        """
        -inputs a list of concepts
        -computes the detail projection, which consists of
        a thing's parts, materials, properties, and instances
        and an event's subevents
        -returns a rank-ordered list of concepts and their scores
        e.g.: (('concept1',score1), ('concept2,score2), ...)
      """
        linktype_weights_dict = {
            'FirstSubeventOf':1.0,
            'LastSubeventOf':1.0,
            'SubeventOf':1.0,
            'MadeOf':1.0,
            'PartOf':1.0,
            'PropertyOf':0.9,
            'IsAInverse':0.2
            }
        return self.get_context(textnode_list,linktype_weights_dict=linktype_weights_dict)
    def project_consequences(self,textnode_list):

        """
        -inputs a list of concepts
        -computes the causal projection, which consists of
        possible consequences of an event or possible actions
        resulting from the presence of a thing
        -returns a rank-ordered list of concepts and their scores
        e.g.: (('concept1',score1), ('concept2,score2), ...)
      """
        linktype_weights_dict = {
            'DesirousEffectOf':1.0,
            'UsedFor':0.4,
            'CapableOf':0.4,
            'CapableOfReceivingAction':0.3,
            'EffectOf':1.0,
            'PrerequisiteEventOfInverse':1.0,
            }
        return self.get_context(textnode_list,linktype_weights_dict=linktype_weights_dict)
    def get_context(self,textnode_list,max_node_visits=500,max_results=200,flow_pinch=300,linktype_weights_dict=None,textnode_list_weighted_p=0):

        """
        the max_node_visits determines how far context will spread
        increasing it adversely affects runtime
        max_results limits the number of results returned
        but changing it does not affect runtime
        flow_pinch limits the number of edges considered
        at each step of the context flow
        the linktype_weights_dict is a python dictionary
        whose keys are the conceptnet relationtypes and whose
        values are a weight assigned to each, in the range [0.0,1.0]
        - to blacklist a linktype, set its weight to 0.0
        - context flow along backedges are regulated by entries in the
        linktype_weights_dict whose key names are "relationtype"+"Inverse"
        - considering inverse flows slow the runtime of this function a bit
        - omitting a relationtype will default to it being blacklisted
        - for reference, the default_linktype_weights_dict is:
            default_linktype_weights_dict = {

                'ConceptuallyRelatedTo':0.1,
                'IsA':0.9,
                'FirstSubeventOf':1.0,
                'DesirousEffectOf':1.0,
                'ThematicKLine':0.8,
                'MadeOf':0.7,
                'SubeventOf':0.9,
                'UsedFor':1.0,
                'SuperThematicKLine':1.0,
                'DefinedAs':1.0,
                'LastSubeventOf':1.0,
                'LocationOf':0.9,
                'CapableOfReceivingAction':0.6,
                'CapableOf':0.8,
                'PrerequisiteEventOf':1.0,
                'MotivationOf':1.0,
                'PropertyOf':1.0,
                'PartOf':1.0,
                'EffectOf':1.0,
                'DesireOf':1.0,
                'ConceptuallyRelatedToInverse':0.0,
                'IsAInverse':0.0,
                'FirstSubeventOfInverse':0.0,
                'DesirousEffectOfInverse':0.0,
                'ThematicKLineInverse':0.0,
                'MadeOfInverse':0.0,
                'SubeventOfInverse':0.0,
                'UsedForInverse':0.0,
                'SuperThematicKLineInverse':0.0,
                'DefinedAsInverse':0.0,
                'LastSubeventOfInverse':0.0,
                'LocationOfInverse':0.0,
                'CapableOfReceivingActionInverse':0.0,
                'CapableOfInverse':0.0,
                'PrerequisiteEventOfInverse':0.0,
                'MotivationOfInverse':0.0,
                'PropertyOfInverse':0.0,
                'PartOfInverse':0.0,
                'EffectOfInverse':0.0,
                'DesireOfInverse':0.0,
                }
        if textnode_list_weighted_p, then each element of textnode_list
        is not a string, but instead, of the form: ('dog',0.5)
        where the cdr is the relative origin weight of that concept.
      """
        default_linktype_weights_dict = {

            'ConceptuallyRelatedTo':0.1,
            'IsA':0.9,
            'FirstSubeventOf':1.0,
            'DesirousEffectOf':1.0,
            'ThematicKLine':0.8,
            'MadeOf':0.7,
            'SubeventOf':0.9,
            'UsedFor':1.0,
            'SuperThematicKLine':1.0,
            'DefinedAs':1.0,
            'LastSubeventOf':1.0,
            'LocationOf':0.9,
            'CapableOfReceivingAction':0.6,
            'CapableOf':0.8,
            'PrerequisiteEventOf':1.0,
            'MotivationOf':1.0,
            'PropertyOf':1.0,
            'PartOf':1.0,
            'EffectOf':1.0,
            'DesireOf':1.0,
            'ConceptuallyRelatedToInverse':0.0,
            'IsAInverse':0.0,
            'FirstSubeventOfInverse':0.0,
            'DesirousEffectOfInverse':0.0,
            'ThematicKLineInverse':0.0,
            'MadeOfInverse':0.0,
            'SubeventOfInverse':0.0,
            'UsedForInverse':0.0,
            'SuperThematicKLineInverse':0.0,
            'DefinedAsInverse':0.0,
            'LastSubeventOfInverse':0.0,
            'LocationOfInverse':0.0,
            'CapableOfReceivingActionInverse':0.0,
            'CapableOfInverse':0.0,
            'PrerequisiteEventOfInverse':0.0,
            'MotivationOfInverse':0.0,
            'PropertyOfInverse':0.0,
            'PartOfInverse':0.0,
            'EffectOfInverse':0.0,
            'DesireOfInverse':0.0,
            }
        decode_node,encode_node,encode_word = self.decode_node,self.encode_node,self.encode_word
        zipped2nodeuid,nodeuid2zipped = self.zipped2nodeuid, self.nodeuid2zipped
        zipped2edgeuid,edgeuid2zipped = self.zipped2edgeuid, self.edgeuid2zipped
        fw_edges,bw_edges = self.fw_edges,self.bw_edges
        all_linktypes = default_linktype_weights_dict.keys()
        if not linktype_weights_dict:
            linktype_weights_dict = default_linktype_weights_dict
        else:
            for linktype in all_linktypes:
                if not linktype_weights_dict.has_key(linktype):
                    linktype_weights_dict[linktype] = 0.0
        forward_linktype_discount_dict = {}
        backward_linktype_discount_dict = {}
        map(lambda x:forward_linktype_discount_dict.__setitem__(encode_word(x),linktype_weights_dict[x]),filter(lambda y:y[-1*len('Inverse'):]!='Inverse',linktype_weights_dict.keys()))
        map(lambda x:backward_linktype_discount_dict.__setitem__(encode_word(x),linktype_weights_dict[x]),map(lambda z:z[:-1*len('Inverse')],filter(lambda y:y[-1*len('Inverse'):]=='Inverse',linktype_weights_dict.keys())))
        forward_linktype_blacklist = filter(lambda x:forward_linktype_discount_dict[x]==0.0,forward_linktype_discount_dict.keys())
        backward_linktype_blacklist = filter(lambda x:backward_linktype_discount_dict[x]==0.0,backward_linktype_discount_dict.keys())
        if len(filter(lambda x:x[1]>0.0,backward_linktype_discount_dict.items())) == 0:
            backward_flow_p = 0
        else:
            backward_flow_p = 1
        if not textnode_list_weighted_p:
            textnode_list = map(lambda x:(x.strip().lower(),1.0),textnode_list)
        else:
            textnode_list = map(lambda x:(x[0].strip().lower(),x[1]),textnode_list)
        textnode_list = filter(lambda x:x[0]!='',textnode_list)
        origin_nodeids = map(lambda x:(zipped2nodeuid(encode_node(x[0].strip())),x[1]),textnode_list)
        queue,visited = [],[]
        origin_nodeids = filter(lambda x:x[0]!=None,origin_nodeids)
        map(lambda x:queue.append(x),origin_nodeids)
        forward_linktype_discount = lambda linktype_uid:forward_linktype_discount_dict.get(linktype_uid,0.1)
        backward_linktype_discount = lambda linktype_uid:backward_linktype_discount_dict.get(linktype_uid,0.1)
        distance_discount = 0.5
        branching_discount = lambda bf,bf_mu=2.5,bf_sigma=1.0:(1./(bf_sigma*((2*math.pi)**0.5)))*(math.e**(-1.*(math.log(bf+5,5)-bf_mu)**2/(2*bf_sigma**2)))
        utter_echo_discount = lambda utter,echo:min(1.0,math.log(utter+0.5*echo+2,3))
        queue = map(lambda x,bd=branching_discount:(x[0],x[1]*bd(len(fw_edges.get(x[0],[])))),queue)
        nodes_seen = 1
        i = 0
        while len(queue)>0 and nodes_seen<max_node_visits:
            if nodes_seen > max_node_visits:
                break
            cur_nodeid,cur_score = queue[0]
            visited.append(queue[0])
            del queue[0]
            fes = fw_edges.get(cur_nodeid,[])
            fes_len = len(fes)
            fes = fes[:flow_pinch]
            fes = map(edgeuid2zipped,fes)
            fes = filter(lambda x:x[0] not in forward_linktype_blacklist,fes)
            forward_next_nodeidscores = map(lambda x,bd=branching_discount,ued=utter_echo_discount,ld=forward_linktype_discount: (x[1],ued(x[2],x[3])*distance_discount*bd(len(fw_edges.get(x[1],[])))*ld(x[0])*cur_score),fes)
            queue += forward_next_nodeidscores
            if backward_flow_p:
                bes = bw_edges.get(cur_nodeid,[])
                bes_len = len(bes)
                bes = bes[:flow_pinch]
                bes = map(edgeuid2zipped,bes)
                bes = filter(lambda x:x[0] not in backward_linktype_blacklist,bes)
                backward_next_nodeidscores = map(lambda x,bd=branching_discount,ued=utter_echo_discount,ld=backward_linktype_discount: (x[1],ued(x[2],x[3])*distance_discount*bd(len(bw_edges.get(x[1],[])))*ld(x[0])*cur_score),bes)
                queue += backward_next_nodeidscores
            queue.sort(lambda x,y:int((y[1]-x[1])*10000))
            queue=queue[:500]
            nodes_seen += 1
        node_dict = {}
        for item in visited:
            nodeid,score = item
            cur_score = node_dict.get(nodeid,0.0)
            new_score = max(score,cur_score)+(1.0-max(score,cur_score))*min(score,cur_score)
            node_dict[nodeid] = new_score
        for origin_nodeid in origin_nodeids:
            if node_dict.has_key(origin_nodeid):
                del node_dict[origin_nodeid]
        items = node_dict.items()
        items.sort(lambda x,y:int((y[1]-x[1])*100))
        output = map(lambda x:(decode_node(nodeuid2zipped(x[0])),x[1]),items[:max_results])
        return output
        
        
        
    def display_node(self,textnode):

        """
        returns the pretty print of a node's contents
      """
        decode_node,encode_node,decode_word = self.decode_node,self.encode_node,self.decode_word
        zipped2nodeuid,nodeuid2zipped = self.zipped2nodeuid, self.nodeuid2zipped
        zipped2edgeuid,edgeuid2zipped = self.zipped2edgeuid, self.edgeuid2zipped
        fw_edges,bw_edges = self.fw_edges,self.bw_edges
        textnode=textnode.strip()
        encoded_node = encode_node(textnode)
        node_uid = zipped2nodeuid(encoded_node)
        fes = map(edgeuid2zipped,fw_edges.get(node_uid,[])[:1000])
        fes.sort(lambda x,y:y[2]+y[3]-x[2]-x[3])
        bes = map(edgeuid2zipped,bw_edges.get(node_uid,[])[:1000])
        bes.sort(lambda x,y:2*(y[2]-x[2])+1*(y[3]--x[3]))
        pp_fw_edges = map(lambda x:'=='+decode_word(x[0])+'==> '+decode_node(nodeuid2zipped(x[1]))+' '+str(x[2:])+'',fes)
        pp_bw_edges = map(lambda x:'<=='+decode_word(x[0])+'== '+decode_node(nodeuid2zipped(x[1]))+' '+str(x[2:])+'',bes)
        output = '['+textnode+']'
        output+= '\n'+ '**OUT:********'
        for line in pp_fw_edges:
            output+= '\n  '+line
        output+='\n'+ '**IN:*********'
        for line in pp_bw_edges:
            output+= '\n  '+line
        return output
    def zipped2nodeuid(self,zipped):
        node_hash = self.node_hash
        uid = node_hash.get(zipped,None)
        if not uid:
                uid = self.getuid()
                node_hash[zipped] = uid
                self.node_lookup[uid] = zipped
        return uid
    def nodeuid2zipped(self,uid):
        return self.node_lookup.get(uid,None)
    def zipped2edgeuid(self,edge):
        edge_hash = self.edge_hash
        edge_uid = edge_hash.get(edge,None)
        if not edge_uid:
            edge_uid = self.getuid()
            edge_hash[edge]=edge_uid
            self.edge_lookup[edge_uid] = edge
        return edge_uid
    def edgeuid2zipped(self,uid):
        return self.edge_lookup.get(uid,None)
    def encode_word(self,word):
        word_hash= self.word_hash
        word_uid = word_hash.get(word,None)
        if not word_uid:
            word_uid = self.getuid()
            word_hash[word] = word_uid
            self.word_lookup[word_uid] = word
        return word_uid
    def decode_word(self,word_uid):
        return self.word_lookup.get(word_uid,None)
    def encode_node(self,textnode):
        toks = textnode.split()
        output_toks = []
        word_hash,word_lookup = self.word_hash,self.word_lookup
        whget = self.word_hash.get
        getuid = self.getuid
        for word in toks:
            word_uid = whget(word,None)
            if not word_uid:
                word_uid = getuid()
                word_hash[word] = word_uid
                word_lookup[word_uid] = word
            output_toks.append(word_uid)
        return tuple(output_toks)
    def decode_node(self,node_tuple):
        wl_get = self.word_lookup.get
        return ' '.join(map(lambda word_uid:wl_get(word_uid,'UNKNOWN'),node_tuple))
    def optimize_order(self):
        fw_edges,bw_edges = self.fw_edges,self.bw_edges
        edgeuid2zipped,zipped2edgeuid = self.edgeuid2zipped,self.zipped2edgeuid
        total_edgesets = len(fw_edges.keys()+bw_edges.keys())
        count = 0
        for edge_set in (fw_edges,bw_edges):
            the_keys = edge_set.keys()
            for node in the_keys:
                count += 1
                if count%3000==0:
                    print "Optimized",count/2,"of",total_edgesets/2,'nodes!\r',
                    sys.stdout.flush()
                edges = edge_set[node]
                edges = map(edgeuid2zipped,edges)
                edges.sort(lambda x,y:2*(y[2]-x[2])+1*(y[3]-x[3]))
                edges = map(zipped2edgeuid,edges)
        print "Optimised",count/2,"of",total_edgesets/2,'nodes!'
    def load_predicates(self):
        for filename in self.predicates_filenames:
            self.load_predicates_file(filename)
    def load_predicates_file(self,filename):
        f=open(filename,'r')
        cur_line = f.readline()
        line_count = 0
        unpp = self.unpp
        encode_node,encode_word = self.encode_node,self.encode_word
        getuid = self.getuid
        zipped2nodeuid,zipped2edgeuid = self.zipped2nodeuid,self.zipped2edgeuid
        fw_edges,bw_edges,node_hash,node_lookup = self.fw_edges,self.bw_edges,self.node_hash,self.node_lookup
        while cur_line:
            line_count += 1
            if line_count % 3000 == 0:
                print filename+':',"Loaded",line_count,"predicates!",'\r',
                sys.stdout.flush()
            if not cur_line.strip():
                continue
            linktype,arg1,arg2,freq,inferred=unpp(cur_line)
            link_uid = encode_word(linktype)
            arg1_compressed = encode_node(arg1)
            arg2_compressed = encode_node(arg2)
            arg1_uid = zipped2nodeuid(arg1_compressed)
            arg2_uid = zipped2nodeuid(arg2_compressed)
            fw_edge = zipped2edgeuid((link_uid,arg2_uid,freq,inferred,))
            bw_edge = zipped2edgeuid((link_uid,arg1_uid,freq,inferred,))
            if not fw_edges.has_key(arg1_uid):
                fw_edges[arg1_uid]=[]
            if not bw_edges.has_key(arg2_uid):
                bw_edges[arg2_uid]=[]
            fw_edges[arg1_uid].append(fw_edge)
            bw_edges[arg2_uid].append(bw_edge)
            cur_line = f.readline()
        f.close()
        print ''
        return
    def getuid(self):

        self.global_uid += 1
        return self.global_uid
    def pp_predicate(self,pred):

        linktype = pred[0]
        args = pred[1:]
        return '('+linktype+' '+' '.join(map(lambda x:'"'+x+'"',args))+')'
    def unpp(self,pp):

        toks = pp.strip(' ()\n').split()
        pred = toks[0]
        args = ' '.join(toks[1:])[1:-1].split('" "')
        f,i = map(lambda x:int(x.split('=')[1]),args.pop().split(';')[:2])
        return pred,args[0],args[1],f,i
        
    def timetest(self,thefile):
        time1=time.time()
        self.load_predicates_file(thefile)
        time2=time.time()
        return "-- test took",str(round(time2-time1,2)),'seconds. --\n'
        
if __name__ == '__main__':
    c = ConceptNetDB()
    print '\n***** INITIALIZING ******'
    print '*************************\n'
    time1=time.time()
    c.load_predicates_file('E:\blank.txt')
    c.load_predicates_file('E:\machine_All.txt')
    time2=time.time()
    print "-- test took",str(round(time2-time1,2)),'seconds. --\n'
