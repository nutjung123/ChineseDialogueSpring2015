//---------------------------------------------------------------------------------
//CNUConcept.cs - version 0.08272006.0d 
//WHAT'S NEW: 
//      
//TO DO:
//
#region using Namespaces
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Xml.Serialization;

using IronPython.Compiler;
using IronPython.Hosting;
using IronPython.Modules;
using IronPython.Runtime;
using IronPython.CodeDom;
using IronPython.Runtime.Types;
using IronPython.Runtime.Exceptions;
using IronPython.Runtime.Calls;
using IronPython.Compiler.Generation;
using IronPython.Runtime.Operations;

using ConceptNetUtils.IPEWrapper;
#endregion

namespace ConceptNetUtils
{
    public class CNUConcept
    {
        #region enums
        /*
            � K-Lines: ConceptuallyRelatedTo, ThematicKLine, SuperThematicKLine
            � Things: IsA, PartOf, PropertyOf, De.nedAs, MadeOf
            � Spatial: LocationOf
            � Events: SubeventOf, PrerequisiteEventOf, First-SubeventOf, LastSubeventOf
            � Causal: EffectOf, DesirousEffectOf
            � Affective: MotivationOf, DesireOf
            � Functional: CapableOfReceivingAction, UsedFor
            � Agents: CapableOf
         */

        /// <summary>
        /// KLines broadly characterize texts along interesting dimensions such as topic and affect.
        /// </summary>
        public enum KLines
        {
            ConceptuallyRelatedTo,
            ThematicKLine,
            SuperThematicKLine
        };

        /// <summary>
        /// Things about the object
        /// </summary>
        public enum Things
        {
            IsA,
            PartOf,
            PropertyOf,
            DefinedAs,
            MadeOf
        };

        /// <summary>
        /// Spetial: Location Of object
        /// </summary>
        public enum Spatial
        {
            LocationOf
        };

        /// <summary>
        /// Events explain any event related to the object.
        /// </summary>
        public enum Events
        {
            SubeventOf,
            PrerequisiteEventOf,
            FirstSubeventOf,
            LastSubeventOf
        };

        /// <summary>
        /// Causal: EffectOf, DesirousEffectOf
        /// </summary>
        public enum Causal
        {
            EffectOf,
            DesirousEffectOf
        };

        /// <summary>
        /// Affective: MotivationOf, DesireOf
        /// (Drives of the object)
        /// </summary>
        public enum Affective
        {
            MotivationOf,
            DesirousEffectOf,
            DesireOf
        };

        /// <summary>
        /// Functional: CapableOfReceivingAction, UsedFor
        /// </summary>
        public enum Functional
        {
            CapableOfReceivingAction,
            UsedFor
        };

        /// <summary>
        /// Agents: CapableOf
        /// </summary>
        public enum Agents
        {
            CapableOf
        };
        #endregion enums

        public static IronPython.Runtime.List affectiveL = new IronPython.Runtime.List();
        public static IronPython.Runtime.List consequencesL = new IronPython.Runtime.List();
        public static IronPython.Runtime.List detailsL = new IronPython.Runtime.List();
        public static IronPython.Runtime.List spatialL = new IronPython.Runtime.List();

        public CNUConcept()
        {
        }

        /// <summary>
        /// Construct a CNUConcept Object
        /// Holds all 20 relationship values and/or information, if any
        /// </summary>
        /// <param name="nodetext">Node-level text</param>
        /// <returns>true if created</returns>
        public bool Create(string nodetext)
        {
            try
            {
                //CNU Init
                affectiveL = ConceptNetUtils.CNDB.project_affective(nodetext);
                consequencesL = ConceptNetUtils.CNDB.project_consequences(nodetext);
                detailsL = ConceptNetUtils.CNDB.project_details(nodetext);
                spatialL = ConceptNetUtils.CNDB.project_spatial(nodetext);


                //Populate enums
                return true;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
                affectiveL = null;
                consequencesL = null;
                detailsL = null;
                spatialL = null;
                return false;
            }

        }

        /// <summary>
        /// Format Object into a readable string.
        /// </summary>
        /// <returns>readable string</returns>
        public string ToString()
        {
            string codestring = "";

            codestring += "Affective: " + affectiveL[0].ToString() + affectiveL[1].ToString() + affectiveL[2].ToString() + Environment.NewLine;
            codestring += "Consequences: " + consequencesL[0].ToString() + consequencesL[1].ToString() + consequencesL[2].ToString() + Environment.NewLine;
            codestring += "Details: " + detailsL[0].ToString() + detailsL[1].ToString() + detailsL[2].ToString() + Environment.NewLine;
            codestring += "Spatial: " + spatialL[0].ToString() + spatialL[1].ToString() + spatialL[2].ToString() + Environment.NewLine;

            return codestring;
        }
    }
}
