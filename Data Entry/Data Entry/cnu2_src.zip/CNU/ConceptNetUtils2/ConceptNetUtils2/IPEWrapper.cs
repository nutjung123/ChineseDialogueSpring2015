//---------------------------------------------------------------------------------
//IPEWrapper.cs - version 2.8.2.0rc
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
//Copyright (c) 2006 by Joseph P. Socoloski III
//LICENSE
//If it is your intent to use this software for non-commercial purposes, 
//such as in academic research, this software is free and is covered under 
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
//---------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ConceptNetUtils.IPEWrapper
{
    public delegate void Response(string text);
  
    public class IPEStreamWrapper : Stream 
    {
        MemoryStream _stream = new MemoryStream();
        Response _response;

        public IPEStreamWrapper(Response response)
        {
            _response = response;
        }

        public override bool CanRead
        {
            get { return false; }
        }

        public override bool CanSeek
        {
            get { return false; }
        }

        public override bool CanWrite
        {
            get { return _stream.CanWrite; }
        }

        public override long Length
        {
            get { return _stream.Length; }
        }

        public override long Position
        {
            get
            {
                return _stream.Position;
            }
            set
            {
                _stream.Position = value;
            }
        }

        public override void Flush()
        {
            _stream.Flush();

            _stream.Seek(0, SeekOrigin.Begin);
            StreamReader sr = new StreamReader(_stream, Encoding.ASCII);
            _response(sr.ReadToEnd());
            sr.Close();
            _stream = new MemoryStream();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            return _stream.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            _stream.SetLength(value);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            return _stream.Read(buffer, offset, count);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            _stream.Write(buffer, offset, count);
        }

        public static StringBuilder sbOutput = new StringBuilder();

        /// <summary>
        /// Method that allows capture of IronPython output
        /// </summary>
        /// <param name="text"></param>
        public static void IPEngineResponse(string text)
        {
            
            if (!string.IsNullOrEmpty(text.Trim()))
            {
                sbOutput.Remove(0, sbOutput.Length);        //Clear
                text = text.Replace("\\n", "\r\n");         //to support newline for textbox use
                sbOutput.Append(text + Environment.NewLine);
            }
        }

        public static object retobject = new object();
        /// <summary>
        /// Method that allows capture of IronPython output
        /// </summary>
        /// <param name="text"></param>
        public static void IPEngineResponseO(object o)
        {
            Type itstype = o.GetType();
            retobject = o;
        }
    }
}
