//---------------------------------------------------------------------------------
//Paths.cs - version 1.2.1.0b
// TextBox control based class designed to be used with Microsoft's IronPython.
// Maybe useful for testing Python scripts with IronPython. 
// WHAT'S NEW:
//      Changed namespace from UIIronTextBox to ConceptNetUtils
//TO DO:
//
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
//Copyright (c) 2006 by Joseph P. Socoloski III
//LICENSE
//If it is your intent to use this software for non-commercial purposes, 
//such as in academic research, this software is free and is covered under 
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
//---------------------------------------------------------------------------------
using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using IronPython.Compiler;
using IronPython.Hosting;
using IronPython.Modules;
using IronPython.Runtime;
using IronPython.Runtime.Exceptions;
using IronPython.Runtime.Calls;
using IronPython.Runtime.Types;
using IronPython.Runtime.Operations;
using IronPython.CodeDom;

namespace ConceptNetUtils
{
    namespace Paths
    {
        /// <summary>
        /// Misc Paths. Customize here.
        /// </summary>
        public class MiscDirs
        {
            /// <summary>
            /// MIT's ConceptNet 2.1 directory.
            /// default: "...MyDocuments) + @"\Python Projects\conceptnet2.1"
            /// </summary>
            public static string ConceptNet = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Python Projects\conceptnet2.1";
            
            /// <summary>
            /// MIT's MontyLingua directory.
            /// default: "...MyDocuments) + @"\Python Projects\conceptnet2.1\montylingua"
            /// </summary>
            public static string montylingua = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Python Projects\conceptnet2.1\montylingua";

            /// <summary>
            /// Visual Studio\Projects Folder.
            /// default: "..MyDocuments) + @"\Visual Studio 2005\Projects"
            /// </summary>
            public static string vs_Projects = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Visual Studio 2005\Projects";

            /*
            /// <summary>
            /// StringCollection of all MiscDirs
            /// </summary>
            public static StringCollection scMiscDirs
            {
                get
                {
                    UIIronTextBox.IronTextBox.scMisc.Clear();
                    UIIronTextBox.IronTextBox.scMisc.Add(ConceptNet);
                    UIIronTextBox.IronTextBox.scMisc.Add(montylingua);
                    UIIronTextBox.IronTextBox.scMisc.Add(vs_Projects); 
                    return UIIronTextBox.IronTextBox.scMisc; }
                //set { UIIronTextBox.IronTextBox.scMisc = value; }
            }
            */

            /// <summary>
            /// Misc Paths.
            /// </summary>
            public MiscDirs()
            {
                
            }
        }

        /// <summary>
        /// Python 2.4 Paths. Customize here.
        /// </summary>
        public class Python24Dirs
        {
            /// <summary>
            /// Folder to Python library modules.
            /// default: "C:\Python24\Lib"
            /// </summary>
            public static string Python24_Lib = @"C:\Python24\Lib";

            /// <summary>
            /// Folder to Tkinter library modules.
            /// default: "C:\Python24\Lib\lib-tk"
            /// </summary>
            public static string Python24_Lib_lib_tk = @"C:\Python24\Lib\lib-tk";

            /// <summary>
            /// default: "C:\Python24\libs"
            /// </summary>
            public static string Python24_libs = @"C:\Python24\libs";

            /// <summary>
            /// default: "C:\Python24\DLLs"
            /// </summary>
            public static string Python24_DLLs = @"C:\Python24\DLLs";

            /// <summary>
            /// Some useful programs written in Python.
            /// default: "C:\Python24\Tools"
            /// </summary>
            public static string Python24_Tools = @"C:\Python24\Tools";

            /// <summary>
            /// Some useful programs written in Python.
            /// default: "C:\Python24\Tools\Scripts"
            /// </summary>
            public static string Python24_Tools_Scripts = @"C:\Python24\Tools\Scripts";

            /*
            /// <summary>
            /// StringCollection of all Python24Dirs
            /// </summary>
            public static StringCollection scPython24Dirs
            {
                get
                {
                    UIIronTextBox.IronTextBox.scPython24.Clear();
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_Lib);
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_Lib_lib_tk);
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_libs);
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_DLLs);
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_Tools);
                    UIIronTextBox.IronTextBox.scPython24.Add(Python24_Tools_Scripts);
                    return UIIronTextBox.IronTextBox.scPython24;
                }
            }
            */

            /// <summary>
            /// Python 2.4 Paths
            /// </summary>
            public Python24Dirs()
            {

            }
        }

        /// <summary>
        /// IronPython Paths. Customize here.
        /// </summary>
        public class IronPythonDirs
        {
            /// <summary>
            /// Current Assembly.Location
            /// </summary>
            public static string Runtime  = Path.GetDirectoryName(typeof(PythonEngine).Assembly.Location);

            /// <summary>
            /// IronPython Tutorial scripts.
            /// default: "...MyDocuments) + @"\Visual Studio 2005\Projects\IronPython-1.0-Beta4\Tutorial"
            /// </summary>
            public static string IronPython_Tutorial = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Visual Studio 2005\Projects\IronPython-1.0-Beta4\Tutorial";

            /// <summary>
            /// IronPython Paths
            /// </summary>
            static IronPythonDirs()
            {

            }
        }

    }

}
