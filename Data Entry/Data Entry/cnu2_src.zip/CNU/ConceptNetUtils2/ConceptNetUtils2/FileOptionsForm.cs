////////////////////////////////
///FileOptionsForm.cs - version 0.01192006.1rc1
///To Do:  Comments and Documentation
///
///
///BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
///Copyright (c) 2006 by Joseph P. Socoloski III
///LICENSE
///If it is your intent to use this software for non-commercial purposes, 
///such as in academic research, this software is free and is covered under 
///the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
///

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO; 
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Xml.Serialization;

namespace ConceptNetUtils
{
    namespace Forms
    {
        /// <summary>
        /// Summary description for FileOptionsForm.
        /// </summary>
        public class FileOptionsForm : System.Windows.Forms.Form
        {
            public static string fullFile1, fullFile2, fullFile3, fullFile4, fullFile5;
            private System.Windows.Forms.GroupBox groupBox1;
            private System.Windows.Forms.Label label1;
            private System.Windows.Forms.Button FileOptionsOK;
            private System.Windows.Forms.OpenFileDialog ofd;
            private System.Windows.Forms.CheckBox chkbFile1;
            private System.Windows.Forms.CheckBox chkbFile2;
            private System.Windows.Forms.CheckBox chkbFile3;
            private System.Windows.Forms.CheckBox chkbFile4;
            private System.Windows.Forms.CheckBox chkbFile5;
            private System.Windows.Forms.Button btBrowseFile1;
            private System.Windows.Forms.Button btBrowseFile2;
            private System.Windows.Forms.Button btBrowseFile3;
            private System.Windows.Forms.Button btBrowseFile4;
            private System.Windows.Forms.Button btBrowseFile5;
            private System.Windows.Forms.Label label2;


            /// <summary>
            /// Required designer variable.
            /// </summary>
            private System.ComponentModel.Container components = null;

            public FileOptionsForm()
            {
                //
                // Required for Windows Form Designer support
                //
                InitializeComponent();

                //
                // TODO: Add any constructor code after InitializeComponent call
                //
            }

            /// <summary>
            /// Clean up any resources being used.
            /// </summary>
            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    if (components != null)
                    {
                        components.Dispose();
                    }
                }
                base.Dispose(disposing);
            }

            #region Windows Form Designer generated code
            /// <summary>
            /// Required method for Designer support - do not modify
            /// the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
                this.ofd = new System.Windows.Forms.OpenFileDialog();
                this.groupBox1 = new System.Windows.Forms.GroupBox();
                this.label2 = new System.Windows.Forms.Label();
                this.btBrowseFile5 = new System.Windows.Forms.Button();
                this.btBrowseFile4 = new System.Windows.Forms.Button();
                this.btBrowseFile3 = new System.Windows.Forms.Button();
                this.btBrowseFile2 = new System.Windows.Forms.Button();
                this.btBrowseFile1 = new System.Windows.Forms.Button();
                this.chkbFile5 = new System.Windows.Forms.CheckBox();
                this.chkbFile4 = new System.Windows.Forms.CheckBox();
                this.chkbFile3 = new System.Windows.Forms.CheckBox();
                this.chkbFile2 = new System.Windows.Forms.CheckBox();
                this.chkbFile1 = new System.Windows.Forms.CheckBox();
                this.FileOptionsOK = new System.Windows.Forms.Button();
                this.label1 = new System.Windows.Forms.Label();
                this.groupBox1.SuspendLayout();
                this.SuspendLayout();
                // 
                // groupBox1
                // 
                this.groupBox1.Controls.Add(this.label2);
                this.groupBox1.Controls.Add(this.btBrowseFile5);
                this.groupBox1.Controls.Add(this.btBrowseFile4);
                this.groupBox1.Controls.Add(this.btBrowseFile3);
                this.groupBox1.Controls.Add(this.btBrowseFile2);
                this.groupBox1.Controls.Add(this.btBrowseFile1);
                this.groupBox1.Controls.Add(this.chkbFile5);
                this.groupBox1.Controls.Add(this.chkbFile4);
                this.groupBox1.Controls.Add(this.chkbFile3);
                this.groupBox1.Controls.Add(this.chkbFile2);
                this.groupBox1.Controls.Add(this.chkbFile1);
                this.groupBox1.Controls.Add(this.FileOptionsOK);
                this.groupBox1.Controls.Add(this.label1);
                this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
                this.groupBox1.Location = new System.Drawing.Point(8, 16);
                this.groupBox1.Name = "groupBox1";
                this.groupBox1.Size = new System.Drawing.Size(496, 376);
                this.groupBox1.TabIndex = 0;
                this.groupBox1.TabStop = false;
                this.groupBox1.Text = "Set Location of Knowledgebase Files...";
                // 
                // label2
                // 
                this.label2.Location = new System.Drawing.Point(16, 152);
                this.label2.Name = "label2";
                this.label2.Size = new System.Drawing.Size(304, 23);
                this.label2.TabIndex = 17;
                this.label2.Text = "Check the files you wish to search...";
                // 
                // btBrowseFile5
                // 
                this.btBrowseFile5.Location = new System.Drawing.Point(400, 312);
                this.btBrowseFile5.Name = "btBrowseFile5";
                this.btBrowseFile5.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile5.TabIndex = 16;
                this.btBrowseFile5.Text = "Browse...";
                this.btBrowseFile5.Click += new System.EventHandler(this.btBrowseFile5_Click);
                // 
                // btBrowseFile4
                // 
                this.btBrowseFile4.Location = new System.Drawing.Point(400, 280);
                this.btBrowseFile4.Name = "btBrowseFile4";
                this.btBrowseFile4.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile4.TabIndex = 15;
                this.btBrowseFile4.Text = "Browse...";
                this.btBrowseFile4.Click += new System.EventHandler(this.btBrowseFile4_Click);
                // 
                // btBrowseFile3
                // 
                this.btBrowseFile3.Location = new System.Drawing.Point(400, 248);
                this.btBrowseFile3.Name = "btBrowseFile3";
                this.btBrowseFile3.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile3.TabIndex = 14;
                this.btBrowseFile3.Text = "Browse...";
                this.btBrowseFile3.Click += new System.EventHandler(this.btBrowseFile3_Click);
                // 
                // btBrowseFile2
                // 
                this.btBrowseFile2.Location = new System.Drawing.Point(400, 216);
                this.btBrowseFile2.Name = "btBrowseFile2";
                this.btBrowseFile2.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile2.TabIndex = 13;
                this.btBrowseFile2.Text = "Browse...";
                this.btBrowseFile2.Click += new System.EventHandler(this.btBrowseFile2_Click);
                // 
                // btBrowseFile1
                // 
                this.btBrowseFile1.Location = new System.Drawing.Point(400, 184);
                this.btBrowseFile1.Name = "btBrowseFile1";
                this.btBrowseFile1.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile1.TabIndex = 12;
                this.btBrowseFile1.Text = "Browse...";
                this.btBrowseFile1.Click += new System.EventHandler(this.btBrowseFile1_Click);
                // 
                // chkbFile5
                // 
                this.chkbFile5.Location = new System.Drawing.Point(24, 312);
                this.chkbFile5.Name = "chkbFile5";
                this.chkbFile5.Size = new System.Drawing.Size(368, 24);
                this.chkbFile5.TabIndex = 11;
                this.chkbFile5.Text = "File 5";
                // 
                // chkbFile4
                // 
                this.chkbFile4.Location = new System.Drawing.Point(24, 280);
                this.chkbFile4.Name = "chkbFile4";
                this.chkbFile4.Size = new System.Drawing.Size(368, 24);
                this.chkbFile4.TabIndex = 10;
                this.chkbFile4.Text = "File 4";
                // 
                // chkbFile3
                // 
                this.chkbFile3.Location = new System.Drawing.Point(24, 248);
                this.chkbFile3.Name = "chkbFile3";
                this.chkbFile3.Size = new System.Drawing.Size(368, 24);
                this.chkbFile3.TabIndex = 9;
                this.chkbFile3.Text = "File 3";
                // 
                // chkbFile2
                // 
                this.chkbFile2.Location = new System.Drawing.Point(24, 216);
                this.chkbFile2.Name = "chkbFile2";
                this.chkbFile2.Size = new System.Drawing.Size(368, 24);
                this.chkbFile2.TabIndex = 8;
                this.chkbFile2.Text = "File 2";
                // 
                // chkbFile1
                // 
                this.chkbFile1.Checked = true;
                this.chkbFile1.CheckState = System.Windows.Forms.CheckState.Checked;
                this.chkbFile1.Location = new System.Drawing.Point(24, 184);
                this.chkbFile1.Name = "chkbFile1";
                this.chkbFile1.Size = new System.Drawing.Size(368, 24);
                this.chkbFile1.TabIndex = 7;
                this.chkbFile1.Text = "File 1";
                // 
                // FileOptionsOK
                // 
                this.FileOptionsOK.Location = new System.Drawing.Point(216, 344);
                this.FileOptionsOK.Name = "FileOptionsOK";
                this.FileOptionsOK.TabIndex = 6;
                this.FileOptionsOK.Text = "OK";
                this.FileOptionsOK.Click += new System.EventHandler(this.FileOptionsOK_Click);
                // 
                // label1
                // 
                this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                this.label1.Location = new System.Drawing.Point(48, 32);
                this.label1.Name = "label1";
                this.label1.Size = new System.Drawing.Size(400, 88);
                this.label1.TabIndex = 0;
                this.label1.Text = @"Set the location of your predicate files.  They may point to other files and not just to ConceptNet files.  Feel free to design your own predicate files.  The Class Library is designed to be customizable.  SearchFor() searches for the word in each line of the file(s) you choose.";



                // 
                // FileOptionsForm
                // 
                this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
                this.ClientSize = new System.Drawing.Size(520, 406);
                this.Controls.Add(this.groupBox1);
                this.Name = "FileOptionsForm";
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
                this.Text = "FileOptionsForm";
                this.Load += new System.EventHandler(this.FileOptionsForm_Load);
                this.groupBox1.ResumeLayout(false);
                this.ResumeLayout(false);

            }
            #endregion

            private void FileOptionsForm_Load(object sender, System.EventArgs e)
            {
                LoadFileSettings(Application.StartupPath + @"\Settings.xml");

                // Create the ToolTip and associate with the Form container.
                ToolTip toolTip1 = new ToolTip();

                // Set up the delays for the ToolTip.
                toolTip1.AutoPopDelay = 1000;
                toolTip1.InitialDelay = 100;
                toolTip1.ReshowDelay = 100;
                // Force the ToolTip text to be displayed whether or not the form is active.
                toolTip1.ShowAlways = true;

                // Set up the ToolTip text for the Button and Checkbox.
                toolTip1.SetToolTip(this.chkbFile1, fullFile1);
                toolTip1.SetToolTip(this.chkbFile2, fullFile2);
                toolTip1.SetToolTip(this.chkbFile3, fullFile3);
                toolTip1.SetToolTip(this.chkbFile4, fullFile4);
                toolTip1.SetToolTip(this.chkbFile5, fullFile5);
            }

            private void FileOptionsOK_Click(object sender, System.EventArgs e)
            {
                string File1 = ""; string File2 = "";
                string File3 = ""; string File4 = "";
                string File5 = "";

                //Current File information is stored in the checkbox.text
                //Trim Prefix created by the checkbox, "File 1: " etc., if null catch
                try
                {
                    if (File1 != "")
                        File1 = chkbFile1.Text.Remove(0, (chkbFile1.Text.IndexOf(":") + 2));
                }
                catch (Exception)
                {
                    File1 = "";
                }

                try
                {
                    if (File2 != "")
                        File2 = chkbFile2.Text.Remove(0, (chkbFile1.Text.IndexOf(":") + 2));
                }
                catch (Exception)
                {
                    File2 = "";
                }

                try
                {
                    if (File3 != "")
                        File3 = chkbFile3.Text.Remove(0, (chkbFile1.Text.IndexOf(":") + 2));
                }
                catch (Exception)
                {
                    File3 = "";
                }

                try
                {
                    if (File4 != "")
                        File4 = chkbFile4.Text.Remove(0, (chkbFile1.Text.IndexOf(":") + 2));
                }
                catch (Exception)
                {
                    File4 = "";
                }

                try
                {
                    if (File5 != "")
                        File5 = chkbFile5.Text.Remove(0, (chkbFile1.Text.IndexOf(":") + 2));
                }
                catch (Exception)
                {
                    File5 = "";
                }

                if (chkbFile1.Checked || chkbFile2.Checked || chkbFile3.Checked || chkbFile4.Checked || chkbFile5.Checked != false)
                {
                    //save textbox info to Settings.xml
                    string path_xmlfiletoopen = (Application.StartupPath + @"\Settings.xml");

                    if (File.Exists(path_xmlfiletoopen))
                    {

                        XmlTextWriter writer = new XmlTextWriter(path_xmlfiletoopen, null);
                        //Use indenting for readability.
                        writer.Formatting = Formatting.Indented;

                        //Write an element (this one is the root).
                        writer.WriteStartElement("SETTINGS");

                        //Write File1
                        if (chkbFile1.Checked != false)
                        {
                            try
                            {
                                writer.WriteStartElement("File1");
                                writer.WriteAttributeString("checked", "yes");
                                writer.WriteString(fullFile1);
                                writer.WriteEndElement();
                            }
                            catch (Exception err)
                            {
                                MessageBox.Show("Error: " + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }
                        else
                        {
                            writer.WriteStartElement("File1");
                            writer.WriteAttributeString("checked", "no");
                            writer.WriteString(fullFile1);
                            writer.WriteEndElement();
                        }

                        //Write File2.
                        if (chkbFile2.Checked != false)
                        {
                            try
                            {
                                writer.WriteStartElement("File2");
                                writer.WriteAttributeString("checked", "yes");
                                writer.WriteString(fullFile2);
                                writer.WriteEndElement();
                            }
                            catch (Exception err)
                            {
                                MessageBox.Show("Error: " + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }
                        else
                        {
                            writer.WriteStartElement("File2");
                            writer.WriteAttributeString("checked", "no");
                            writer.WriteString(fullFile2);
                            writer.WriteEndElement();
                        }

                        //Write File3.
                        if (chkbFile3.Checked != false)
                        {
                            try
                            {
                                writer.WriteStartElement("File3");
                                writer.WriteAttributeString("checked", "yes");
                                writer.WriteString(fullFile3);
                                writer.WriteEndElement();
                            }
                            catch (Exception err)
                            {
                                MessageBox.Show("Error: " + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }
                        else
                        {
                            writer.WriteStartElement("File3");
                            writer.WriteAttributeString("checked", "no");
                            writer.WriteString(fullFile3);
                            writer.WriteEndElement();
                        }

                        //Write File4.
                        if (chkbFile4.Checked != false)
                        {
                            try
                            {
                                writer.WriteStartElement("File4");
                                writer.WriteAttributeString("checked", "yes");
                                writer.WriteString(fullFile4);
                                writer.WriteEndElement();
                            }
                            catch (Exception err)
                            {
                                MessageBox.Show("Error: " + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }
                        else
                        {
                            writer.WriteStartElement("File4");
                            writer.WriteAttributeString("checked", "no");
                            writer.WriteString(fullFile4);
                            writer.WriteEndElement();
                        }

                        //Write File5.
                        if (chkbFile5.Checked != false)
                        {
                            try
                            {
                                writer.WriteStartElement("File5");
                                writer.WriteAttributeString("checked", "yes");
                                writer.WriteString(fullFile5);
                                writer.WriteEndElement();
                            }
                            catch (Exception err)
                            {
                                MessageBox.Show("Error: " + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }
                        else
                        {
                            writer.WriteStartElement("File5");
                            writer.WriteAttributeString("checked", "no");
                            writer.WriteString(fullFile5);
                            writer.WriteEndElement();
                        }

                        //Write the close tag for the root element.
                        writer.WriteEndElement();

                        //Write the XML to file and close the writer.
                        writer.Flush();
                        writer.Close();

                        this.Close();
                    }
                    else
                        MessageBox.Show(@"Path to and/or Settings.xml file not found. You may need to add an \");
                }
                else
                    MessageBox.Show("One file must be checked.");
            }

            private void btBrowseFile1_Click(object sender, System.EventArgs e)
            {
                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    fullFile1 = ofd.FileName;
                    chkbFile1.Text = "File 1: " + ofd.FileName.Remove(0, ofd.FileName.LastIndexOf(@"\") + 1);
                    chkbFile1.Update();
                }
            }

            private void btBrowseFile2_Click(object sender, System.EventArgs e)
            {
                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    fullFile2 = ofd.FileName;
                    chkbFile2.Text = "File 2: " + ofd.FileName.Remove(0, ofd.FileName.LastIndexOf(@"\") + 1);
                    chkbFile2.Update();
                }
            }

            private void btBrowseFile3_Click(object sender, System.EventArgs e)
            {
                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    fullFile3 = ofd.FileName;
                    chkbFile3.Text = "File 3: " + ofd.FileName.Remove(0, ofd.FileName.LastIndexOf(@"\") + 1);
                    chkbFile3.Update();
                }
            }

            private void btBrowseFile4_Click(object sender, System.EventArgs e)
            {
                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    fullFile4 = ofd.FileName;
                    chkbFile4.Text = "File 4: " + ofd.FileName.Remove(0, ofd.FileName.LastIndexOf(@"\") + 1);
                    chkbFile4.Update();
                }
            }

            private void btBrowseFile5_Click(object sender, System.EventArgs e)
            {

                ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                ofd.ShowDialog();

                if (ofd.FileName != string.Empty)
                {
                    fullFile5 = ofd.FileName;
                    chkbFile5.Text = "File 5: " + ofd.FileName.Remove(0, ofd.FileName.LastIndexOf(@"\") + 1);
                    chkbFile5.Update();
                }
            }

            /// <summary>
            /// Returns string of data in an element node.
            /// </summary>
            /// <param name="path_xmlfilename">Path and filename to any XML file.</param>
            /// <param name="node">Element tag to find.</param>
            private string XMLGetNode(string path_xmlfilename, string node)
            {
                string nodedata = "";

                try
                {
                    if (File.Exists(path_xmlfilename))
                    {
                        XmlTextReader StatsReader = null;
                        StatsReader = new XmlTextReader(path_xmlfilename);

                        while (StatsReader.Read())
                        {
                            if (StatsReader.NodeType == XmlNodeType.Element)
                            {
                                if (StatsReader.LocalName.Equals(node))
                                {
                                    nodedata = StatsReader.ReadString();
                                    StatsReader.Close();
                                }
                            }
                        }
                    }
                    else
                        nodedata = path_xmlfilename + " file not found to read node data.";
                }
                catch (Exception err)
                {
                    MessageBox.Show("Error: " + err.Message, "Error. Can not read " + path_xmlfilename, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                return nodedata;
            }

            /// <summary>
            /// Loads Settings.xml file to the checkboxes.text
            /// </summary>
            /// <param name="path_xmlfilename">Path and filename to any XML file.</param>
            private void LoadFileSettings(string path_xmlfilename)
            {

                if (File.Exists(path_xmlfilename))
                {
                    XmlTextReader StatsReader = null;
                    StatsReader = new XmlTextReader(path_xmlfilename);
                    string curNodename = "";
                    try
                    {
                        while (StatsReader.Read())
                        {
                            if ((StatsReader.NodeType == XmlNodeType.Element) && (StatsReader.LocalName != "SETTINGS") && StatsReader.IsEmptyElement == false)
                            {
                                curNodename = StatsReader.LocalName;
                                if (curNodename == "File1")
                                {
                                    //MessageBox.Show(StatsReader.GetAttribute("checked"));
                                    //Check to see if it is set as checked or uncheck, then do
                                    if (StatsReader.GetAttribute("checked") == "yes")
                                        chkbFile1.Checked = true;
                                    else
                                        chkbFile1.Checked = false;

                                    fullFile1 = StatsReader.ReadString();
                                    chkbFile1.Text = "File 1: " + fullFile1.Remove(0, fullFile1.LastIndexOf(@"\") + 1);

                                    chkbFile1.Update();
                                }
                                if (curNodename == "File2")
                                {
                                    //Check to see if it is set as checked or uncheck, then do
                                    if (StatsReader.GetAttribute("checked") == "yes")
                                        chkbFile2.Checked = true;
                                    else
                                        chkbFile2.Checked = false;

                                    fullFile2 = StatsReader.ReadString();
                                    chkbFile2.Text = "File 2: " + fullFile2.Remove(0, fullFile2.LastIndexOf(@"\") + 1);

                                    chkbFile2.Update();
                                }
                                if (curNodename == "File3")
                                {
                                    //Check to see if it is set as checked or uncheck, then do
                                    if (StatsReader.GetAttribute("checked") == "yes")
                                        chkbFile3.Checked = true;
                                    else
                                        chkbFile3.Checked = false;

                                    fullFile3 = StatsReader.ReadString();
                                    chkbFile3.Text = "File 3: " + fullFile3.Remove(0, fullFile3.LastIndexOf(@"\") + 1);

                                    chkbFile3.Update();
                                }
                                if (curNodename == "File4")
                                {
                                    //Check to see if it is set as checked or uncheck, then do
                                    if (StatsReader.GetAttribute("checked") == "yes")
                                        chkbFile4.Checked = true;
                                    else
                                        chkbFile4.Checked = false;

                                    fullFile4 = StatsReader.ReadString();
                                    chkbFile4.Text = "File 4: " + fullFile4.Remove(0, fullFile4.LastIndexOf(@"\") + 1);

                                    chkbFile4.Update();
                                }
                                if (curNodename == "File5")
                                {
                                    //Check to see if it is set as checked or uncheck, then do
                                    if (StatsReader.GetAttribute("checked") == "yes")
                                        chkbFile5.Checked = true;
                                    else
                                        chkbFile5.Checked = false;

                                    fullFile5 = StatsReader.ReadString();
                                    chkbFile5.Text = "File 5: " + fullFile5.Remove(0, fullFile5.LastIndexOf(@"\") + 1);

                                    chkbFile5.Update();
                                }
                            }
                        }
                        StatsReader.Close();
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Error: " + err.Message, "Error. Can not read " + path_xmlfilename, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                    MessageBox.Show(@"Path to and/or Settings.xml file not found. Create a Settings.xml or perform reinstall.");

            }

        }
    }
}
