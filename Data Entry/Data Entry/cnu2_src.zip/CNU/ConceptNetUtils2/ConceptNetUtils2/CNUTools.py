import re,math
#import montylingua
import CNUMontylingua
import CNUDB
__version__ = "2.0"
__author__ = "hugo@media.mit.edu modified by Joseph P. Socoloski III July 2, 2006"
__url__ = 'www.conceptnet.org'
class ConceptNetNLTools:


    def __init__(self,ConceptNetDB_handle=None):

        self.m = CNUMontylingua.MontyLingua()
        if not ConceptNetDB_handle:
            ConceptNetDB_handle = ConceptNetDB.ConceptNetDB()
        self.db = ConceptNetDB_handle
    def guess_mood(self,text):

        """
        -inputs a raw text document
        -computes an affective classification of the document
        using paul ekman's six basic emotions
        - outputs the following six-tuple of pairs:
          (
           ('happy', 0.5),
           ('sad', 0.4),
           ('angry', 0.3),
           ('fearful', 0.9),
           ('disgusted', 0.0),
           ('surprised', 0.0),
          )
        - the cdr of each pair is a score in the range [0.0,1.0]
        representing the relative presence of that mood in the
        document
      """
        naive_ekman = [
        ['happy','happiness','joy','joyful','joyfulness','cheer','cheerful','cheerfulness','smile'],
        ['sad','sadness','despair','depressed','depression'],
        ['anger','angered','upset','mad','angry','angriness'],
        ['fear','fearful','fright','scared','feared','scare','frighten','frightened','anxious','anxiety','panic','terror','horror','intimidation','creep','chill','shiver','frisson','danger','dangerous'],
        ['disgust','disgusted','dislike','abhorrence','abomination','detest','detestation','exercration','loathe','loathing','odium','hate','repugnance','repulsion','revulsion','horror'],
        ['surprise','surprised','surprising','surprisal','astonish','amazement','amaze','excite','excitement','exciting','shock','stun','stunning','shocking','bombshell','unexpected','sudden','thrill','tingle']
        ]
        max_results =1000
        pairs = self.guess_topic(text,max_results)[1]
        classes = [0.0]*len(naive_ekman)


        class_names = ['happy','sad','angry','fearful','disgusted','surprised']


        sensitivities = [('happy',0.5),
                         ('sad',1.0),
                         ('angry',0.7),
                         ('fearful',0.4),
                         ('digusted',0.9),
                         ('surprised',0.9)
                         ]
        for a in range(len(pairs)):
            (word,score) = pairs[a]
            for i in range(len(naive_ekman)):
                if word in naive_ekman[i]:
                    classes[i] += sensitivities[i][1]*(score+(a*1.0/max_results))


        output_pairs = [(class_names[i],classes[i]) for i in range(len(class_names))]
        output_pairs.sort(lambda x,y:int(y[1]*100000-x[1]*100000))
        return output_pairs
    def summarize_document(self,text,summary_size=5):

        """
        inputs a raw text document
        outputs an algorithmically generated summary
        summary_size sets the size of the summary to generate,
        in sentences
        algorithm for summarization is:
        1) compute a document vector using guess_topic()
        2) compute sentence vectors using get_context()
        3) saliency is the strength of each sentence vector
        4) sentences are rank-ordered by saliency and pruned
        to summary size
      """
        refine_arg = self.refine_arg
        db = self.db
        get_context = db.get_context
        jist_subj_events = self.jist_subj_events
        parse_pred_arg = self.parse_pred_arg
        document_vector = self.guess_topic(text)[1]
        document_vector_dict = {}
        map(lambda x:document_vector_dict.__setitem__(x[0],x[1]),document_vector)
        scored_sentence_infos = []
        sentence_infos = self.generate_extraction(text)
        for i in range(len(sentence_infos)):
            info = sentence_infos[i]
            pp = info['parameterized_predicates']
            if len(pp)<1: continue
            pp1 = pp[0]
            if len(pp1)<3: continue
            verb,subj,obj1=pp1[0:3]
            if subj[0]=='' or verb[0]=='': continue
            compound_concepts = map(lambda x:x[1],jist_subj_events([info]))
            concepts = compound_concepts + info['noun_phrases'] + info['modifiers'] + info['adj_phrases'] + info['prep_phrases']
            sentence_vector = get_context(concepts,max_node_visits=50,max_results=1000,flow_pinch=200,linktype_weights_dict=None,textnode_list_weighted_p=0)
            score = 0.0
            for concept,value in sentence_vector:
                score += value*document_vector_dict.get(concept,0.0)
            scored_sentence_infos.append( (info,i,score) )
        scored_sentence_infos.sort(lambda x,y:int(y[2]*100-x[2]*100))
        pruned = scored_sentence_infos[:summary_size]
        pruned.sort(lambda x,y:x[1]-y[1])
        vsoos = []
        for info,position,score in pruned:
            vsoos += map(parse_pred_arg,info['verb_arg_structures_concise'])
        return self.m.generate_summary(vsoos)
    def guess_topic(self,text,max_results=1000,flow_pinch=500,max_node_visits=1000):

        """
        -inputs a raw text document
        - extracts events, adjectives, and things from text
        and finds their weighted contextual intersection
        - returns a pair whose car is a trace of the
        list of entities extracted from the text,
        and cdr are the results (in the same format as the
        return type of get_context)
      """
        refine_arg = self.refine_arg
        db = self.db
        get_context = db.get_context
        extraction = self.generate_extraction(text)
        events = filter(lambda z:z!=None,map(refine_arg,map(lambda x:x[1],self.jist_subj_events(extraction))))
        entities = filter(lambda z:z!=None,map(refine_arg,self.jist_entities(extraction)))
        adjs = self.jist_adjs(extraction)
        pxs = filter(lambda z:z!=None,map(refine_arg,self.jist_pxs(extraction)))
        weights = {'events':1.0,'entities':0.8,'pxs':0.7,'adjs':0.4}
        document_vector = map(lambda x:(x,weights['events']),events)
        document_vector += map(lambda x:(x,weights['entities']),entities)
        document_vector += map(lambda x:(x,weights['pxs']),pxs)
        document_vector += map(lambda x:(x,weights['adjs']),adjs)
        document_vector = map(lambda x:(x[0].lower(),x[1]),document_vector)
        car= map(lambda x:x[0],document_vector)
        linktype_weights_dict = {
            'ConceptuallyRelatedTo':0.1,
            'IsA':0.9,
            'FirstSubeventOf':0.2,
            'DesirousEffectOf':0.2,
            'ThematicKLine':0.6,
            'MadeOf':0.2,
            'SubeventOf':0.2,
            'UsedFor':0.9,
            'SuperThematicKLine':1.0,
            'DefinedAs':0.9,
            'LastSubeventOf':0.2,
            'LocationOf':0.9,
            'CapableOfReceivingAction':0.6,
            'CapableOf':0.6,
            'PrerequisiteEventOf':0.9,
            'MotivationOf':1.0,
            'PropertyOf':0.4,
            'PartOf':0.3,
            'EffectOf':1.0,
            'DesireOf':1.0,
            'ConceptuallyRelatedToInverse':0.0,
            'IsAInverse':0.0,
            'FirstSubeventOfInverse':1.0,
            'DesirousEffectOfInverse':0.0,
            'ThematicKLineInverse':0.0,
            'MadeOfInverse':0.0,
            'SubeventOfInverse':1.0,
            'UsedForInverse':0.0,
            'SuperThematicKLineInverse':0.0,
            'DefinedAsInverse':0.0,
            'LastSubeventOfInverse':1.0,
            'LocationOfInverse':0.0,
            'CapableOfReceivingActionInverse':0.0,
            'CapableOfInverse':0.7,
            'PrerequisiteEventOfInverse':0.0,
            'MotivationOfInverse':0.0,
            'PropertyOfInverse':0.7,
            'PartOfInverse':1.0,
            'EffectOfInverse':0.0,
            'DesireOfInverse':0.5,
            }
        output = get_context(document_vector,max_node_visits=1000,max_results=1000,linktype_weights_dict=linktype_weights_dict,textnode_list_weighted_p=1)
        return (car,output)
    def guess_concept(self,text,simple_results_p=0):

        """
        -inputs a raw text document
        - the input is an egocentric description where
        the subject is a mystery concept being described
        - for example: 'Foo is red and delicious. Foo
        spoils when it's been laid out too long. Foo has
        a stem and meat and skin.'
        - uses structure mapping similar to get_analogous_concepts()
        to guess what the mystery concept might be
        - the return type is the same as with get_analogous_concepts()
        - if simple_results_p = 1, then output object is simply
        a list of rank-ordered concepts
      """
        db = self.db
        refine_arg = self.refine_arg
        encode_word,decode_word = db.encode_word,db.decode_word
        zipped2nodeuid,nodeuid2zipped = db.zipped2nodeuid,db.nodeuid2zipped
        encode_node,decode_node = db.encode_node,db.decode_node
        zipped2edgeuid,edgeuid2zipped = db.zipped2edgeuid,db.edgeuid2zipped
        bw_edges = db.bw_edges
        extraction = self.generate_extraction(text)
        vsoos = self.jist_vsoos(extraction)
        entities = filter(lambda z:z!=None,map(refine_arg,self.jist_entities(extraction)))
        adjs = filter(lambda z:z!=None,self.jist_adjs(extraction))
        pxs = filter(lambda z:z!=None,map(refine_arg,self.jist_pxs(extraction)))
        dossier = []
        for vsoo in vsoos:
            print vsoo
            v,s,objs = vsoo[0],vsoo[1],vsoo[2:]
            if v == 'have':
                dossier.append(('PartOf',' '.join(objs)))
            elif v == 'be':
                dossier.append(('IsA',' '.join(objs)))
                dossier.append(('PropertyOf',' '.join(objs)))
            plausible_preds = ['UsedFor','DesireOf','SubeventOf','EffectOf','DefinedAs','CapableOf']
            for p in plausible_preds:
                dossier.append((p,' '.join([v]+objs)))
                if len(objs)>1:
                    dossier.append((p,' '.join([v]+[objs[0]])))
                semantically_ambiguous = ['have','be','get','achieve','act','allow','appear','become','come','could','do','feel','go','give','know','lay','leave','let','make','may','mean','meet','might','must','ought','put','provide','set','shall','should','show','take','tell','think','will','would','use']
                if v not in semantically_ambiguous:
                    dossier.append((p,' '.join([v])))
        for adj in adjs:
            dossier.append(('PropertyOf',adj))
        for px in pxs:
            dossier.append(('LocationOf',px))
        dossier = map(lambda x:(x[0],x[1].lower()),dossier)
        uniq = {}
        map(lambda x:uniq.__setitem__(x,1),dossier)
        dossier = uniq.keys()
        linktype_weights = {'PropertyOf':2.0,'UsedFor':1.5,'CapableOf':1.5}
        print dossier
        fes = map(lambda x:(encode_word(x[0]),zipped2nodeuid(encode_node(x[1].strip())),1,0),dossier)
        print 'fes',fes
        candidates = {}
        for fe in fes:
            commonpred,commonnode,f,i = fe
            bes = map(edgeuid2zipped, bw_edges.get(commonnode,[]))
            bes = filter(lambda x:x[0]==commonpred,bes)
            print bes
            for be in bes:
                commonpred2,candidate,f2,i2 = be
                link_strength = 1.0
                weight = link_strength*linktype_weights.get(decode_word(commonpred),1.0)
                candidates[candidate] = candidates.get(candidate,[])+[(commonpred,commonnode,weight)]
        scored_candidates = map(lambda x:(x[0],x[1],sum(map(lambda y:y[2],x[1]))),candidates.items())
        scored_candidates.sort(lambda x,y:int(1000*(y[2]-x[2])))
        scored_candidates = map(lambda y:(decode_node(nodeuid2zipped(y[0])),
                                          map(lambda x:
                                              (decode_word(x[0]),decode_node(nodeuid2zipped(x[1])),weight),
                                              y[1]),
                                          y[2]),
                                scored_candidates)
        print dossier
        if simple_results_p:
            return map(lambda x:x[0],scored_candidates)
        return scored_candidates
    def jist_pxs(self,extraction):

        """
        -inputs an extraction object
        -returns a list of all the prepositional phrases
        in the extraction object
      """
        infos = extraction
        entities = []
        for info in infos:
            pxs = info['prep_phrases']
            entities += pxs
        return entities
    def jist_adjs(self,extraction):

        """
        -inputs an extraction object
        -returns a list of all the adjectival phrases
        and modifiers in the extraction object
      """
        infos = extraction
        entities = []
        for info in infos:
            axs = info['adj_phrases']
            adjs = info['modifiers']
            entities += axs+adjs
        uniq = {}
        map(lambda x:uniq.__setitem__(x,1),entities)
        entities = uniq.keys()
        return entities
    def jist_entities(self,extraction):

        """
        -inputs an extraction object
        -returns a list of all the noun chunks
        in the extraction object
      """
        infos = extraction
        entities = []
        for info in infos:
            nxs = info['noun_phrases']
            entities += nxs
        return entities
    def jist_vsoos(self,extraction):

        """
        -inputs an extraction object
        -returns a list of Verb-Subject-Object-Object
        tuples, each of the form: ('read','I','book','in bed')
        - all words are lemmatised, and semantically empty tokens
        are stripped (e.g.: the, a, modals)
      """
        unpp_predicate = self.unpp_predicate
        infos = extraction
        svoos_list = []
        for info in infos:
            svoos = info['verb_arg_structures_concise']
            svoos = map(unpp_predicate,svoos)
            svoos_list+=svoos
        return svoos_list
    def jist_subj_events(self,extraction):

        """
        -inputs an extraction object
        -returns entries like: ('I','read book')
      """
        unpp_predicate = self.unpp_predicate
        infos = extraction
        svoos_list = []
        for info in infos:
            svoos = info['verb_arg_structures_concise']
            svoos = map(unpp_predicate,svoos)
            svoos_list+=svoos
        subj_events = []
        for entry in svoos_list:
            if len(entry)<=2:
                subj_events.append( (entry[1],entry[0]) )
                continue
            subj_events.append( (entry[1],entry[0]+' '+entry[2]) )
            if len(entry)>=4:
                subj_events.append( (entry[1],' '.join([entry[0]]+entry[2:])) )
        return subj_events
    def generate_extraction(self,text):

        """
        -inputs a raw text document
        -outputs an extraction object which contains a
        parsed digest of the text
        -the extraction object can be passed as argument
        to methods jist_*()
      """
        m=self.m
        sentences = m.split_sentences(text)
        tokenized = map(m.tokenize,sentences)
        tagged = map(m.tag_tokenized,tokenized)
        chunked = map(m.chunk_tagged,tagged)
        extracted = map(m.extract_info,chunked)
        return extracted
    def unpp_predicate(self,pp_pred):

        pp_pred = pp_pred.strip()[1:-1]
        pp_pred = pp_pred.split()
        pred = pp_pred[0]
        pp_pred = ' '.join(pp_pred[1:])
        args = pp_pred[1:-1].split('" "')
        return [pred.strip('"')]+args
    def postchunk_px(self,chunked):

        return self.m.theMontyChunker.postchunk_px(chunked)
    def lemmatise(self,text):

        """
        -inputs a raw text document
        -outputs lemmatised text
      """
        m=self.m
        toked_text = m.tokenize(text)
        tagged_text = m.tag_tokenized(toked_text)
        lemmatised_text = m.lemmatise_tagged(tagged_text)
        return ' '.join(map(lambda x:x.split('/')[2],lemmatised_text.split()))
    def chunk_and_lemmatise(self,text):

        m=self.m
        toked_text = m.tokenize(text)
        tagged_text = m.tag_tokenized(toked_text)
        lemmatised_text = m.lemmatise_tagged(tagged_text)
        chunked = m.chunk_lemmatised(lemmatised_text)
        return chunked
    def chunk(self,text):

        m=self.m
        toked_text = m.tokenize(text)
        tagged_text = m.tag_tokenized(toked_text)
        chunked = m.chunk_tagged(tagged_text)
        return chunked
    def tag(self,text):

        m=self.m
        toked_text = m.tokenize(text)
        tagged_text = m.tag_tokenized(toked_text)
        return tagged_text
    def refine_arg(self,arg,re_pattern=None):

        re_grammar = {
            'IsA':['^ NX $','^ NX (PX )*$'],
            'default':['^ (VX )*(AX )*(NX )*(PX )*$','^ (VX )*(AX )*(NX )*(PX )*$'],
            }
        if not re_pattern:
            re_pattern = re_grammar['default'][0]
        arg_chunked = self.postchunk_px(self.chunk(arg))
        res = self.arg_grammar_accept_p(arg_chunked,re_pattern)
        if not res:
            arg_chunked = self.repair_arg(arg_chunked,re_pattern)
            res = self.arg_grammar_accept_p(arg_chunked,re_pattern)
            if not res:
                return None
        toks = arg_chunked.split()
        for i in range(len(toks)):
            if '/' not in toks[i]:
                toks[i] = '/'+toks[i]
        stop_pos = ['DT','MD',',','.']
        for i in range(len(toks)):
            word,pos = toks[i].split('/')
            if pos in stop_pos:
                toks[i]=''
                continue
            elif pos=='RB' and word.lower()!='not':
                toks[i]=''
                continue
        normalized = (' '.join(toks)).lower()
        normalized = ' '.join(filter(lambda y:y!='',map(lambda x: x.split('/')[0],normalized.split())))
        normalized = self.lemmatise(normalized)
        normalized = self.apply_swaplist(normalized)
        return normalized
    def apply_swaplist(self,text):

        swaplist = [
        ['people \'s','person \'s'],
        ['people','person'],
        ['someone \'s','person \'s'],
        ['someone','person'],
        ['anyone \'s','person \'s'],
        ['anyone','person'],
        ['everyone \'s','person \'s'],
        ['everyone','person'],
        ['my','person \'s'],
        ['me','person'],
        ['i','person'],
        ['your','person \'s'],
        ['you','person'],
        ['their','person \'s'],
        ['them','person'],
        ['they','person'],
        ['his','person \'s'],
        ['he','person'],
        ['her','person \'s'],
        ['she','person'],
        ]
        text = ' '+text+' '
        swaplist.sort()
        for swapper in swaplist:
            trigger,conseq = swapper
            text =text.replace(' '+trigger+' ',' '+conseq+' ')
        return text.strip()
    def repair_arg(self,arg_chunked,re_pattern):

        return arg_chunked
    def parse_pred_arg(self,pp):

        """
        parses the predicate-argument string
        returned by jist_predicates(), of the form:
        '("pred name" "arg 1" "arg 2" etc)'
        and returns them as a list
        """
        pp.strip
        toks = pp.strip()[1:-1].split()
        args = ' '.join(toks)[1:-1].split('" "')
        return args
    def arg_grammar_accept_p(self,arg_chunked,re_pattern):

        toks = arg_chunked.split()
        for i in range(len(toks)):
            if '/' not in toks[i]:
                toks[i] = '/'+toks[i]
        tags = map(lambda x:x.split('/')[1],toks)
        processed_tags_str = ' '+' '.join(tags)+' '
        collapse_re = " \((.X) .+? (.X)\) "
        collapse_re = re.compile(collapse_re)
        dirtyBit = 1
        while dirtyBit:
            dirtyBit = 0
            m = collapse_re.search(processed_tags_str)
            if m:
                dirtyBit = 1
                chunk_type = m.groups()[0]
                processed_tags_str = processed_tags_str[:m.start()]+' '+chunk_type+' '+processed_tags_str[m.end():]
        arg_pattern = ' '+' '.join(processed_tags_str.split())+' '
        m = re.search(re_pattern,arg_pattern)
        if m:
            return 1
        else:
            return 0
if __name__ == '__main__':
    c = ConceptNetNLTools()
