//---------------------------------------------------------------------------------
//ConceptNetUtils.cs - version 2.8.2.0rc
// C# version of MIT's ConceptNet 2.1 
//WHAT'S NEW: 
//      -Added Relationship enums
//      -Added CNUConcept Class (Holds Affective, Consequences, Details, and Spacial Lists)
//      -Added guess_topic() to CNTools class
//      -Changed some Converts methods to public static
//      -Changed Converts.Convert_ListtoString to Converts.Convert_ArrayListtoString
//      -Added guess_concept() to CNTools class
//      -Changed some "textnode_list" variables to "textnode" because they are not lists
//TO DO:
//      -Check to make sure no null values are being passed into the methods
//      -Add as many ConceptNet methods as can be
//
//BY DOWNLOADING AND USING, YOU AGREE TO THE FOLLOWING TERMS:
//Copyright (c) 2006 by Joseph P. Socoloski III
//LICENSE
//If it is your intent to use this software for non-commercial purposes, 
//such as in academic research, this software is free and is covered under 
//the GNU GPL License, given here: <http://www.gnu.org/licenses/gpl.txt> 
//---------------------------------------------------------------------------------
#region using Namespaces
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Xml.Serialization;

using IronPython.Compiler;
using IronPython.Hosting;
using IronPython.Modules;
using IronPython.Runtime;
using IronPython.CodeDom;
using IronPython.Runtime.Types;
using IronPython.Runtime.Exceptions;
using IronPython.Runtime.Calls;
using IronPython.Compiler.Generation;
using IronPython.Runtime.Operations;

using ConceptNetUtils.IPEWrapper;
#endregion

namespace ConceptNetUtils
{
    #region CNDB Class
    [ToolboxItem(true)]
    [ToolboxBitmap(typeof(CNDB))]
    public class CNDB
    {
        #region CNDB/ConceptNetDB Notes:
        /*
         * The following ConceptNet 2.1 ConceptNetDB methods are not yet added 
         * to the CNU Library but may be called by using PythonEngine.Execute, etc
            def zipped2nodeuid(self,zipped)
            def nodeuid2zipped(self,uid)
            def zipped2edgeuid(self,edge)
            def edgeuid2zipped(self,uid)
            def encode_word(self,word)
            def decode_word(self,word_uid)
            def encode_node(self,textnode)
            def decode_node(self,node_tuple)
            def optimize_order(self)
            def load_predicates(self)
            def getuid(self)
         */
        #endregion CNDB/ConceptNetDB Notes:

        #region IronPython Prep and helper methods
        /// <summary>
        /// Global IronPython Engine for the application
        /// </summary>
        public static PythonEngine cn_pe = new PythonEngine();

        #endregion IronPython Prep and helper methods

        private static string conceptnet21Dir = "";

        /// <summary>
        /// Gets and Sets path to ConceptNet 2.1 on local machine.
        /// Updates the current PythonEngine
        /// default: Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Python Projects\conceptnet2.1"
        /// </summary>
        public static string ConceptNet21path
        {
            get
            {
                return conceptnet21Dir;
            }
            set
            {
                conceptnet21Dir = value;
            }

        }

        #region Initialize
        /// <summary>
        /// Creates semantic network using IronPython Engine and modified ConceptNet script files
        /// </summary>
        /// <param name="ConceptNetDB_handle">Gets passed as self.nltools = ConceptNetNLTools_handle</param>
        public static void Initialize(object ConceptNetDB_handle)
        {
            MessageBox.Show("Copy Initialize() source when IronPython embedded file support is better. Do IT!");
            Initialize();
        }

        /// <summary>
        /// Creates semantic network using IronPython Engine and modified ConceptNet script files
        /// </summary>
        public static void Initialize()
        {
            try
            {

                //Handle the engine's output
                //Make sure cn_pe.SetStandardOutput(new ConceptNetUtils.IPEStreamWrapper.IPEStreamWrapper(IPEngineResponse)); is called from calling method
                cn_pe.Execute("import sys");
                cn_pe.Import("imp");

                //add the necessary paths for the scripts to run
                cn_pe.AddToPath(ConceptNetUtils.Paths.Python24Dirs.Python24_Lib);
                cn_pe.AddToPath(ConceptNetUtils.Paths.Python24Dirs.Python24_libs);
                cn_pe.AddToPath(ConceptNetUtils.Paths.MiscDirs.ConceptNet);
                cn_pe.AddToPath(ConceptNetUtils.Paths.MiscDirs.montylingua);
                cn_pe.AddToPath(Environment.CurrentDirectory);
                //cn_pe.AddToPath("E:\\");    //remove this when complete

                /*
                //Load the embedded files.
                // Python array module is overridden by array.py.
                // ConceptNet 2.1 script files: 
                // -ConceptNetDB.py, ConceptNetNLTools.py, MontyCommonsense.py, 
                //   MontyLexiconCustom.py, MontyLexiconFast.py, Montylingua.py, 
                //   MontyNLGenerator.py, MontyTagger.py. 
                // Modified by Joseph P. Socoloski III July 2, 2006. Remaining files 
                // did not need modification and worked under IronPython (Beta8).

                //*NOTE: Currently IronPython beta8 does not allow easy importing of
                //  .py files when they are embedded. Below is a lengthy workaround.

                IronPython.Runtime.SymbolId arrayCode_SymbolId = (SymbolId)"arrayCode";
                cn_pe.SetGlobal(arrayCode_SymbolId, Misc.getEmbeddedResourceContent("array.py"));
                cn_pe.Execute("newModule = imp.new_module('array')");
                cn_pe.Execute("exec(arrayCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['array'] = newModule");

                IronPython.Runtime.SymbolId CNUMontyLexiconCustomCode_SymbolId = (SymbolId)"CNUMontyLexiconCustomCode";
                cn_pe.SetGlobal(CNUMontyLexiconCustomCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyLexiconCustom.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontyLexiconCustom')");
                cn_pe.Execute("exec(CNUMontyLexiconCustomCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyLexiconCustom'] = newModule");

                IronPython.Runtime.SymbolId CNUMontyNLGeneratorCode_SymbolId = (SymbolId)"CNUMontyNLGeneratorCode";
                cn_pe.SetGlobal(CNUMontyNLGeneratorCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyNLGenerator.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontyNLGenerator')");
                cn_pe.Execute("exec(CNUMontyNLGeneratorCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyNLGenerator'] = newModule");

                IronPython.Runtime.SymbolId CNUMontyLexiconFastCode_SymbolId = (SymbolId)"CNUMontyLexiconFastCode";
                cn_pe.SetGlobal(CNUMontyLexiconFastCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyLexiconFast.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontyLexiconFast')");
                cn_pe.Execute("exec(CNUMontyLexiconFastCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyLexiconFast'] = newModule");

                //Create empty CNUMontyCommonsense for CNUMontyTagger
                IronPython.Runtime.SymbolId CNUMontyCommonsenseCode_SymbolId = (SymbolId)"CNUMontyCommonsenseCode";
                cn_pe.SetGlobal(CNUMontyCommonsenseCode_SymbolId, "");
                cn_pe.Execute("newModule = imp.new_module('CNUMontyCommonsense')");
                cn_pe.Execute("exec(CNUMontyCommonsenseCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyCommonsense'] = newModule");

                IronPython.Runtime.SymbolId CNUMontyTaggerCode_SymbolId = (SymbolId)"CNUMontyTaggerCode";
                cn_pe.SetGlobal(CNUMontyTaggerCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyTagger.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontyTagger')");
                cn_pe.Execute("exec(CNUMontyTaggerCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyTagger'] = newModule");

                //Create full CNUMontyCommonsense for CNUMontyTagger
                cn_pe.SetGlobal(CNUMontyCommonsenseCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyCommonsense.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontyCommonsense')");
                cn_pe.Execute("exec(CNUMontyCommonsenseCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontyCommonsense'] = newModule");

                //Create full MontyCommonsense for cn_pe.modules
                IronPython.Runtime.SymbolId MontyCommonsenseCode_SymbolId = (SymbolId)"MontyCommonsenseCode";
                cn_pe.SetGlobal(MontyCommonsenseCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontyCommonsense.py"));
                cn_pe.Execute("newModule = imp.new_module('MontyCommonsense')");
                cn_pe.Execute("exec(MontyCommonsenseCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['MontyCommonsense'] = newModule");

                IronPython.Runtime.SymbolId CNUMontylinguaCode_SymbolId = (SymbolId)"CNUMontylinguaCode";
                cn_pe.SetGlobal(CNUMontylinguaCode_SymbolId, Misc.getEmbeddedResourceContent("CNUMontylingua.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUMontylingua')");
                cn_pe.Execute("exec(CNUMontylinguaCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUMontylingua'] = newModule");

                //Create empty CNUDB for CNUTools
                IronPython.Runtime.SymbolId CNUDBCode_SymbolId = (SymbolId)"CNUDBCode";
                cn_pe.SetGlobal(CNUDBCode_SymbolId, "");
                cn_pe.Execute("newModule = imp.new_module('CNUDB')");
                cn_pe.Execute("exec(CNUDBCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUDB'] = newModule");

                IronPython.Runtime.SymbolId CNUToolsCode_SymbolId = (SymbolId)"CNUToolsCode";
                cn_pe.SetGlobal(CNUToolsCode_SymbolId, Misc.getEmbeddedResourceContent("CNUTools.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUTools')");
                cn_pe.Execute("exec(CNUToolsCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUTools'] = newModule");

                //Create full CNUDB
                cn_pe.SetGlobal(CNUDBCode_SymbolId, Misc.getEmbeddedResourceContent("CNUDB.py"));
                cn_pe.Execute("newModule = imp.new_module('CNUDB')");
                cn_pe.Execute("exec(CNUDBCode, newModule.__dict__)");
                cn_pe.Execute("sys.modules['CNUDB'] = newModule");

                                /*
 * Fast Lexicon Found! Now Loading!
Traceback (most recent call last):
File , line 0, in <stdin>##70
File E:\CNUDB.py, line 24, in __init__                          [self.nltools = CNUTools.ConceptNetNLTools(self)]
File E:\CNUTools.py, line 13, in __init__                       [self.m = CNUMontylingua.MontyLingua()]
File E:\CNUMontylingua.py, line 15, in __init__                 [self.theMontyLemmatiser = MontyLemmatiser.MontyLemmatiser()]
File E:\CNUMontyTagger.py, line 15, in __init__                 [self.theLexicon=CNUMontyLexiconFast.MontyLexiconFast()]
File E:\CNUMontyLexiconFast.py, line 37, in __init__            [self.load_fastlexicon()] (found .MDF file "FASTLEXICON")
File E:\CNUMontyLexiconFast.py, line 101, in load_fastlexicon   [line1=self.array_fromfile(res_arr,self.word_start_arr,built_in_p,self.java_p,java_code='ws')]
                 *                                                  res_arr = "<open file './montylingua/FASTLEXICON_3.MDF', mode 'rb' at 0x00EA...
                 *                                                  self.word_start_arr = <huge array 0xc32bc0>
                 *                                                  built_in_p = 260759  
                 *                                                  line1 = None
File CNUMontyLexiconFast, line unknown, in array_fromfile       ?
File E:\CNUMontyLexiconFast.py, line 254, in array_fromfile     [array_ptr.fromfile(file_ptr,length)]  file_ptr = "<open file './montylingua/FASTLEXICON_3.MDF', mode 'rb' at 0x00C9...
File E:\array.py, line 209, in fromfile                         [self.fromstring(item)]
File E:\array.py, line 222, in fromstring                       [s = str(s)]
File mscorlib, line unknown, in GetString
File mscorlib, line unknown, in GetString
File mscorlib, line unknown, in CreateStringFromEncoding
File mscorlib, line unknown, in GetCharCount
File mscorlib, line unknown, in InternalFallback
File mscorlib, line unknown, in Fallback
File mscorlib, line unknown, in Throw
UnicodeDecodeError: Unable to translate bytes [81] at index 0 from specified cod
e page to Unicode.
>>>*/

                cn_pe.Execute("import CNUDB");
                cn_pe.Execute("import os");
                cn_pe.Execute("os.chdir('" + ConceptNetUtils.Paths.MiscDirs.ConceptNet + "')"); //Needed to load predicate files
                cn_pe.Execute("c=CNUDB.ConceptNetDB()");
                //** when array.py line uncommented, Unable to translate bytes [81] at index 0 from specified code page to Unicode.**

                cn_pe.Execute("print 'ConceptNet Utilities version 2.8.2.0rc is ready for use.'");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                MessageBox.Show(cn_pe.FormatException(ex));
            }
        }
        #endregion Initialize

        #region get_analogous_concepts tested and finished 7-9-06
        /// <summary>
        /// If simple_results_p = 1, then output object is simply
        /// a list of rank-ordered concepts
        /// </summary>
        /// <param name="textnode">node-level text.</param>
        /// <returns>Returns an IronPython List of rank-ordered concepts if simple_results_p = 1</returns>
        public static List get_analogous_concepts(string textnode)
        {
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode"] = textnode;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_analogous_concepts(textnode.encode('ascii','strict').strip())");

                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// If simple_results_p = 1, then output object is simply
        /// a list of rank-ordered concepts
        /// </summary>
        /// <param name="textnode">node-level text.</param>
        /// <param name="simple_results_p"></param>
        /// <returns>Returns an IronPython Tuple of rank-ordered concepts if simple_results_p = 1</returns>
        public static Tuple get_analogous_concepts(string textnode, int simple_results_p)
        {
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode"] = textnode;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_analogous_concepts(textnode.encode('ascii','strict').strip()), simple_results_p");

                return (Tuple)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return Tuple.MakeTuple("");
            }
        }
        #endregion get_analogous_concepts finished 7-9-06

        #region misc methods tested and finished 7-11-06
        /// <summary>
        /// Computes all available contextual projections.
        /// </summary>
        /// <param name="textnode">node-level text.</param>
        /// <returns>Returns an IronPython List of pairs. ('ProjectionName',(('concept1',score1), ('concept2,score2), ...))</returns>
        public static List get_all_projections(string textnode)
        {
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode"] = textnode;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.Execute("r=c.get_analogous_concepts(textnode.encode('ascii','strict').strip())");
                return (List)cn_pe.Globals["r"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }
    
        /// <summary>
        /// Computes the affective projection, which is the emotional context and consequences underlying these concepts.
        /// </summary>
        /// <param name="textnode_list">Node-level text.</param>
        /// <returns>Returns a rank-ordered IronPython List of concepts and their scores.</returns>
        public static List project_affective(string textnode_list)
        {
            try
            {
                Dict linktype_weights_dict = new Dict();
                linktype_weights_dict.Add("DesireOf", 1.0);
                linktype_weights_dict.Add("DesirousEffectOf", 1.0);
                linktype_weights_dict.Add("MotivationOf", 1.0);
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), linktype_weights_dict=linktype_weights_dict)");

                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// computes the spatial projection, which consists of relevant locations, relevant objects in the same scene.
        /// </summary>
        /// <param name="textnode_list">Document-level text.</param>
        /// <returns>Returns a rank-ordered IronPython List of concepts and their scores.</returns>
        public static List project_spatial(string textnode_list)
        {
            try
            {
                Dict linktype_weights_dict = new Dict();
                linktype_weights_dict.Add("LocationOf", 1.0);
                linktype_weights_dict.Add("ThematicKLine", 0.5);
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), linktype_weights_dict=linktype_weights_dict)");

                return (List)cn_pe.Globals["r"];

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Computes the detail projection, which consists of a thing's parts, 
        /// materials, properties, and instances and an event's subevents.
        /// </summary>
        /// <param name="textnode_list">Document-level text.</param>
        /// <returns>Returns a rank-ordered IronPython List of concepts and their scores.</returns>
        public static List project_details(string textnode_list)
        {
            try
            {
                Dict linktype_weights_dict = new Dict();
                linktype_weights_dict.Add("FirstSubeventOf", 1.0);
                linktype_weights_dict.Add("LastSubeventOf", 1.0);
                linktype_weights_dict.Add("SubeventOf", 1.0);
                linktype_weights_dict.Add("MadeOf", 1.0);
                linktype_weights_dict.Add("PartOf", 1.0);
                linktype_weights_dict.Add("PropertyOf", 0.9);
                linktype_weights_dict.Add("IsAInverse", 0.2);
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), linktype_weights_dict=linktype_weights_dict)");

                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Computes the causal projection, which consists of possible consequences of an 
        /// event or possible actions resulting from the presence of a thing.
        /// </summary>
        /// <param name="textnode_list">Document-level text.</param>
        /// <returns>Returns a rank-ordered IronPython List of concepts and their scores.</returns>
        public static List project_consequences(string textnode_list)
        {
            try
            {
                Dict linktype_weights_dict = new Dict();
                linktype_weights_dict.Add("DesirousEffectOf", 1.0);
                linktype_weights_dict.Add("UsedFor", 0.4);
                linktype_weights_dict.Add("CapableOf", 0.4);
                linktype_weights_dict.Add("CapableOfReceivingAction", 0.3);
                linktype_weights_dict.Add("EffectOf", 1.0);
                linktype_weights_dict.Add("PrerequisiteEventOfInverse", 1.0);
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), linktype_weights_dict=linktype_weights_dict)");

                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Returns IronPython List of the matching predicate nodes for a node-level text.
        /// </summary>
        /// <param name="textnode">node-level text</param>
        /// <returns>Returns a IronPython List.</returns>
        public static string display_node(string textnode)
        {
            try
            {
                cn_pe.Globals["textnode"] = textnode;
                cn_pe.ExecuteToConsole("r=\"\"");
                cn_pe.ExecuteToConsole("r=c.display_node(textnode_list.encode('ascii','strict'))");

                return (string)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString(), ex.Message);
                return ex.Message;
                //return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Load a predicate file into the semantic network.
        /// </summary>
        /// <param name="fullpredfilename">Full path and filename of predicate file.</param>
        public static void load_predicates_file(string fullpredfilename)
        {
            try
            {
                cn_pe.Globals["fullpredfilename"] = fullpredfilename;
                cn_pe.ExecuteToConsole("a=c.load_predicates_file(fullpredfilename)");

                //return (string)cn_pe.Globals["a"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                //return List.MakeEmptyList(4);
            }
        }
        /// <summary>
        /// Load a string to return it in a special format.
        /// </summary>
        /// <param name="pred">Predicate line.</param>
        /// <returns>String with every character in double quotes, except the first. eg '(a, "p", "p", "l", "e")'.</returns>
        public static string pp_predicate(string pred)
        {
            try
            {
                cn_pe.Globals["pred"] = pred;
                cn_pe.ExecuteToConsole("a=c.pp_predicate(pred)");

                return (string)cn_pe.Globals["a"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString(), ex.Message);
                return ex.Message;
                //return List.MakeEmptyList(4);
            }
        }
        /// <summary>
        /// Unpacks a predicate line into a IronPython.Runtime.Tuple.
        /// </summary>
        /// <param name="pred">Predicate line.</param>
        /// <returns>IronPython.Runtime.Tuple of prediate line.</returns>
        public static Tuple unpp(string pp)
        {
            try
            {
                cn_pe.Globals["pp"] = pp;
                cn_pe.ExecuteToConsole("a=c.unpp(pp)");

                //Bug: print messages not displayed 7-10-06
                return (Tuple)cn_pe.Globals["a"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return Tuple.MakeTuple("");
            }
        }
        #endregion misc methods finished and tested 7-11-06

        #region get_context tested and finished 7-9-06
        /// <summary>
        /// Get context from node-level text. Returns IronPython List of related topics.
        /// </summary>
        /// <param name="textnode_list">node-level text.</param>
        /// <returns>Returns IronPython List of related topics.</returns>
        public static List get_context(string textnode_list)
        {
            //defaults: max_node_visits=500,max_results=200,flow_pinch=300,linktype_weights_dict=None,textnode_list_weighted_p=0 
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')))");
                
                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Get context from node-level text. Returns IronPython List of related topics.
        /// </summary>
        /// <param name="textnode_list">node-level text.</param>
        /// <param name="max_node_visits">Determines how far context will spread.</param>
        /// <param name="max_results">Limits the number of results returned.</param>
        /// <param name="flow_pinch">Limits the number of edges considered at each step of the context flow.</param>
        /// <param name="linktype_weights_dict">Python dictionary whose keys are the conceptnet relationtypes and whose values are a weight assigned to each, in the range [0.0,1.0].</param>
        /// <param name="textnode_list_weighted_p">If textnode_list_weighted_p, then each element of textnode_list is not a string, but instead, of the form: ('dog',0.5).</param>
        /// <returns>Returns IronPython List of related topics</returns>
        public static List get_context(string textnode_list, Dict linktype_weights_dict)
        {
            //textnode_list,max_node_visits=500,max_results=200,flow_pinch=300,linktype_weights_dict=None,textnode_list_weighted_p=0 
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), linktype_weights_dict=linktype_weights_dict)");
                
                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Get context from node-level text. Returns IronPython List of related topics.
        /// </summary>
        /// <param name="textnode_list">node-level text.</param>
        /// <param name="max_node_visits">Determines how far context will spread. default=500</param>
        /// <param name="max_results">Limits the number of results returned. default=200</param>
        /// <param name="flow_pinch">Limits the number of edges considered at each step of the context flow. default=300</param>
        /// <param name="linktype_weights_dict">Python dictionary whose keys are the conceptnet relationtypes and whose values are a weight assigned to each, in the range [0.0,1.0]. default=None</param>
        /// <param name="textnode_list_weighted_p">If textnode_list_weighted_p, then each element of textnode_list is not a string, but instead, of the form: ('dog',0.5). default=0</param>
        /// <returns>Returns IronPython List of related topics</returns>
        public static List get_context(string textnode_list, int max_node_visits, int max_results, int flow_pinch)
        {
            //textnode_list,max_node_visits=500,max_results=200,flow_pinch=300,linktype_weights_dict=None,textnode_list_weighted_p=0 
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.Globals["max_node_visits"] = max_node_visits;
                cn_pe.Globals["max_results"] = max_results;
                cn_pe.Globals["flow_pinch"] = flow_pinch;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), max_node_visits=max_node_visits, max_results=max_results, flow_pinch=flow_pinch)");
                
                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Get context from node-level text. Returns IronPython List of related topics.
        /// </summary>
        /// <param name="textnode_list">node-level text.</param>
        /// <param name="max_node_visits">Determines how far context will spread. default=500</param>
        /// <param name="max_results">Limits the number of results returned. default=200</param>
        /// <param name="flow_pinch">Limits the number of edges considered at each step of the context flow. default=300</param>
        /// <param name="linktype_weights_dict">Python dictionary whose keys are the conceptnet relationtypes and whose values are a weight assigned to each, in the range [0.0,1.0]. default=None</param>
        /// <param name="textnode_list_weighted_p">If textnode_list_weighted_p, then each element of textnode_list is not a string, but instead, of the form: ('dog',0.5). default=0</param>
        /// <returns>Returns IronPython List of related topics</returns>
        public static List get_context(string textnode_list, int max_node_visits, int max_results, int flow_pinch, Dict linktype_weights_dict, int textnode_list_weighted_p)
        {
            //textnode_list,max_node_visits=500,max_results=200,flow_pinch=300,linktype_weights_dict=None,textnode_list_weighted_p=0 
            try
            {
                cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                cn_pe.Globals["textnode_list"] = textnode_list;
                cn_pe.Globals["max_node_visits"] = max_node_visits;
                cn_pe.Globals["max_results"] = max_results;
                cn_pe.Globals["flow_pinch"] = flow_pinch;
                cn_pe.Globals["linktype_weights_dict"] = linktype_weights_dict;
                cn_pe.Globals["textnode_list_weighted_p"] = textnode_list_weighted_p;
                cn_pe.ExecuteToConsole("r={}");
                cn_pe.ExecuteToConsole("r=c.get_context(map(lambda tok:tok.strip(),textnode_list.encode('ascii','strict').split(',')), max_node_visits=max_node_visits, max_results=max_results, flow_pinch=flow_pinch, linktype_weights_dict=linktype_weights_dict, textnode_list_weighted_p=textnode_list_weighted_p)");
                
                return (List)cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }
        #endregion get_context finished 7-9-06

    }
    #endregion CNDB Class

    #region CNTools Class
    public class CNTools
    {
        #region CNTools/ConceptNetNLTools Notes:
        /*
         * The following ConceptNet 2.1 ConceptNetNLTools methods are not yet added 
         * to the CNU Library but may be called by using PythonEngine.Execute, etc
            def guess_mood(self,text)
            def summarize_document(self,text,summary_size=5)
            def jist_pxs(self,extraction)
            def jist_adjs(self,extraction)
            def jist_entities(self,extraction)
            def jist_vsoos(self,extraction)
            def jist_subj_events(self,extraction)
            def unpp_predicate(self,pp_pred)
            def postchunk_px(self,chunked)
            def lemmatise(self,text)
            def chunk_and_lemmatise(self,text)
            def refine_arg(self,arg,re_pattern=None)
            def apply_swaplist(self,text)
            def repair_arg(self,arg_chunked,re_pattern)
            def parse_pred_arg(self,pp)
            def arg_grammar_accept_p(self,arg_chunked,re_pattern)
         */
        #endregion CNTools/ConceptNetNLTools Notes:

        #region tested and finished 8-13-06
        /// <summary>
        /// Returns a string of incoming text tagged by MontyLingua. eg: "(NX apple/NN NX)"
        /// </summary>
        /// <param name="text">Desired text to be chunked.</param>
        /// <returns>String of incoming text chunked by MontyLingua. eg: "(NX apple/NN NX)"</returns>
        public static string chunk(string text)
        {
            try
            {
                IronPython.Runtime.SymbolId text_SymbolId = (SymbolId)"text";
                CNDB.cn_pe.Globals["text"] = text;
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.chunk(text)");

                return (string)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString(), ex.Message);
                return ex.Message;
                //return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Returns a string of incoming text tagged by MontyLingua. eg: "apple/NN"
        /// </summary>
        /// <param name="text">Desired text to be tagged.</param>
        /// <returns>String of incoming text tagged by MontyLingua. eg: "apple/NN"</returns>
        public static string tag(string text)
        {
            try
            {
                IronPython.Runtime.SymbolId text_SymbolId = (SymbolId)"text";
                CNDB.cn_pe.Globals["text"] = text;
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.tag(text)");

                return (string)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString(), ex.Message);
                return ex.Message;
                //return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Outputs an extraction IronPython.Runtime.List object which contains a parsed digest of the text.
        /// eg: {'noun_phrases_tagged': ['apple/NN', 'tall/JJ tree/NN'], 'noun_phrases': ['apple', 'tall tree'],...
        /// </summary>
        /// <param name="text">Raw text document.</param>
        /// <returns>IronPython.Runtime.List containing parsed digest of the text. eg: {'noun_phrases_tagged': ['apple/NN', 'tall/JJ tree/NN'], 'noun_phrases': ['apple', 'tall tree'],...</returns>
        public static List generate_extraction(string text)
        {
            try
            {
                IronPython.Runtime.SymbolId text_SymbolId = (SymbolId)"text";
                CNDB.cn_pe.Globals["text"] = text;
                CNDB.cn_pe.ExecuteToConsole("r={}");
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.generate_extraction(text)");

                return (List)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// Guesses the topic of a Document-level text
        /// </summary>
        /// <param name="textnode_list">Document-level text</param>
        /// <returns></returns>
        public static Tuple guess_topic(string textnode_list)
        {
            //guess_topic(self,text,max_results=1000,flow_pinch=500,max_node_visits=1000)
            try
            {
                CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                CNDB.cn_pe.Globals["textnode_list"] = textnode_list;
                //CNDB.cn_pe.ExecuteToConsole("r={}");
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.guess_topic(textnode_list.encode('ascii','strict').strip())");

                return (Tuple)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return Tuple.Make("");
            }
        }
        #endregion tested and finished 8-13-06

        #region guess_concept
        /// <summary>
        /// def guess_concept(self,text,simple_results_p=0)
        /// </summary>
        /// <param name="textdoc"></param>
        /// <returns></returns>
        public static List guess_concept(string textdoc)
        {
            try
            {
                CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                CNDB.cn_pe.Globals["textdoc"] = textdoc;
                CNDB.cn_pe.ExecuteToConsole("r={}");
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.guess_concept(textdoc.encode('ascii','strict').strip())");

                return (List)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return List.MakeEmptyList(4);
            }
        }

        /// <summary>
        /// If simple_results_p = 1, then output object is simply
        /// a list of rank-ordered concepts
        /// </summary>
        /// <param name="textdoc">document-level text.</param>
        /// <param name="simple_results_p"></param>
        /// <returns>Returns an IronPython Tuple of rank-ordered concepts if simple_results_p = 1</returns>
        public static Tuple guess_concept(string textdoc, int simple_results_p)
        {
            try
            {
                CNDB.cn_pe.SetStandardOutput(new ConceptNetUtils.IPEWrapper.IPEStreamWrapper(IPEWrapper.IPEStreamWrapper.IPEngineResponse));
                CNDB.cn_pe.Globals["textdoc"] = textdoc;
                CNDB.cn_pe.ExecuteToConsole("r={}");
                CNDB.cn_pe.ExecuteToConsole("r=c.nltools.guess_concept(textdoc.encode('ascii','strict').strip()), simple_results_p");

                return (Tuple)CNDB.cn_pe.Globals["r"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), ex.Message);
                //return ex.Message;
                return Tuple.MakeTuple("");
            }
        }
        #endregion guess_concept

    }
    #endregion CNTools Class

    #region Misc Class
    public class Misc
    {
        /// <summary>
        /// Get an embedded text file resource file.
        /// reference: http://blogs.clearscreen.com/ragc/archive/2004/06/09/316.aspx
        /// </summary>
        /// <param name="resourceFileName">Filename of the resource.</param>
        /// <returns>string</returns>
        public static string getEmbeddedResourceContent(string resourceFileName)
        {
            Assembly myAssembly = Assembly.GetExecutingAssembly();
            string resName = String.Empty;
            foreach (string resourceName in myAssembly.GetManifestResourceNames())
            {
                if (resourceName.IndexOf(resourceFileName) >= 0)
                {
                    resName = resourceName;
                    break;
                }
            }
            if (resName.Length > 0)
            {
                Stream s = myAssembly.GetManifestResourceStream(resName);
                StreamReader sr = new StreamReader(s, System.Text.Encoding.GetEncoding(1252));
                return sr.ReadToEnd();
            }
            else
            {
                throw new Exception("The resource can't be found");
            }
        }

        /// <summary>
        /// Returns string of data in an element node.
        /// </summary>
        /// <param name="path_xmlfilename">Path and filename to any XML file.</param>
        /// <param name="element">Element tag to find.</param>
        public static string GetXMLElement(string path_xmlfilename, string element)
        {
            string nodedata = "";

            if (File.Exists(path_xmlfilename))
            {
                XmlTextReader StatsReader = null;
                StatsReader = new XmlTextReader(path_xmlfilename);

                while (StatsReader.Read())
                {
                    if (StatsReader.NodeType == XmlNodeType.Element)
                    {
                        if (StatsReader.LocalName.Equals(element))
                        {
                            nodedata = StatsReader.ReadString();
                            StatsReader.Close();
                        }
                    }
                }
            }
            else
                MessageBox.Show(path_xmlfilename + " file not found to read node data.");

            return nodedata;
        }

        /// <summary>
        /// Returns string without the "K-Lines: " or "Spatial: ", if All then remove string after
        /// </summary>
        /// <param name="R_TYPE">String of desired relationship type(s) to be searching for + prefix of "category :".</param>
        public string RemoveCategoryString(string R_TYPE)
        {
            string justType = "";
            int index = 0;

            if (R_TYPE.IndexOf(":") != -1)
            {
                index = R_TYPE.IndexOf(":");
                justType = R_TYPE.Remove(0, index + 1);
            }
            else
            {
                if (R_TYPE == "All (Returns all results with word)")
                    justType = "All";
                else
                    justType = R_TYPE;
            }
            return justType.Trim();
        }

        /// <summary>
        /// Returns string of data in an element node.
        /// </summary>
        /// <param name="path_xmlfilename">Path and filename to any XML file.</param>
        /// <param name="elementname">String of Element's name of desired data.</param>
        public string XMLGetNode(string path_xmlfilename, string elementname)
        {
            string nodedata = "";
            try
            {
                if (File.Exists(path_xmlfilename))
                {
                    XmlTextReader StatsReader = null;
                    StatsReader = new XmlTextReader(path_xmlfilename);

                    while (StatsReader.Read())
                    {
                        if (StatsReader.NodeType == XmlNodeType.Element)
                        {
                            if (StatsReader.LocalName.Equals(elementname))
                            {
                                nodedata = StatsReader.ReadString();
                                StatsReader.Close();
                            }
                        }
                    }
                }
                else
                    nodedata = path_xmlfilename + " file not found to read node data.";
            }
            catch
            {
                nodedata = "XMLGetNode Error.";
            }

            return nodedata;
        }


        /// <summary>
        /// Returns string of Attribute data in an element node.
        /// </summary>
        /// <param name="path_xmlfilename">Path and filename to any XML file.</param>
        /// <param name="elementname">String of Element's name of desired data.</param>
        /// <param name="attributename">String of Attribute's name of desired data.</param>
        public string XMLGetAttribute(string path_xmlfilename, string elementname, string attributename)
        {
            string attributedata = "";

            try
            {
                if (File.Exists(path_xmlfilename))
                {
                    XmlTextReader StatsReader = null;
                    StatsReader = new XmlTextReader(path_xmlfilename);

                    while (StatsReader.Read())
                    {
                        if (StatsReader.NodeType == XmlNodeType.Element)
                        {
                            if (StatsReader.LocalName.Equals(elementname))
                            {
                                attributedata = StatsReader.GetAttribute(attributename);
                                StatsReader.Close();
                            }
                        }
                    }
                }
                else
                    attributedata = path_xmlfilename + " file not found to read node data.";
            }
            catch
            {
                attributedata = "XMLGetAttribute Error.";
            }

            return attributedata;
        }

        /// <summary>
        /// Creates a Text File, catch overwriting existing files
        /// </summary>
        /// <param name="path_filename">Path and filename.</param>
        /// <param name="data">String to save to the file.</param>
        /// <param name="overwrite">Set "true" to overwite existing files.</param>
        public bool CreateTextFile(string path_filename, string data, bool overwrite)
        {
            bool filecreated = false;

            try
            {
                if (File.Exists(path_filename) && overwrite == false)
                {
                    MessageBox.Show("{0} already exists.", path_filename);
                    filecreated = false;
                }
                else
                {
                    File.AppendAllText(path_filename, data + "\r\n");
                    filecreated = true;
                }
            }
            catch
            {
                filecreated = false;
            }

            return filecreated;
        }


        /// <summary>
        /// Add a line to the end of a text file. Creates file if file not found.
        /// </summary>
        /// <param name="path_filename">Path and filename.</param>
        /// <param name="line_data">String to save to the file.</param>
        public bool AddLine(string path_filename, string line_data)
        {
            bool successful = false;

            File.AppendAllText(path_filename, line_data + "\r\n");

            return successful;
        }

        /// <summary>
        /// Create a ConceptNet line and add it to a text file.
        /// example: (IsA "cactus" "plant" "f=2;i=1;")
        /// takes f and i values in as strings
        /// </summary>
        /// <param name="R_Type">String of relationship type.</param>
        /// <param name="sub_word">String of word (word1).</param>
        /// <param name="comp_word">String of complimentary word (word1).</param>
        /// <param name="f_value">String of where f= # of utterances.</param>
        /// <param name="i_value">String of where i= # of times inferred.</param>
        public string Create_CNLine(string R_Type, string sub_word, string comp_word, string f_value, string i_value)
        {
            string CNLine;

            CNLine = "(" + R_Type + " \"" + sub_word + "\" " + "\"" + comp_word + "\" " + "\"f=" + f_value + ";i=" + i_value + ";\")";

            return CNLine;
        }

        /// <summary>
        /// Create a ConceptNet line and add it to a text file.
        /// example: (IsA "cactus" "plant" "f=2;i=1;")
        /// takes f and i values in as integers
        /// </summary>
        /// <param name="R_Type">String of relationship type.</param>
        /// <param name="sub_word">String of word (word1).</param>
        /// <param name="comp_word">String of complimentary word (word1).</param>
        /// <param name="f_value">Integer of where f= # of utterances.</param>
        /// <param name="i_value">Integer of where i= # of times inferred.</param>
        public string Create_CNLine(string R_Type, string sub_word, string comp_word, int f_value, int i_value)
        {
            string CNLine;

            CNLine = "(" + R_Type + " \"" + sub_word + "\" " + "\"" + comp_word + "\" " + "\"f=" + Convert.ToString(f_value) + ";i=" + Convert.ToString(i_value) + ";\")";

            return CNLine;
        }

        /// <summary>
        /// Returns string of Relationship
        /// </summary>
        /// <param name="index">Integer index representing the relationship types 0-19. IsA is the default.</param>
        public string GetRelationshipText(int index)
        {
            string relationship = "";

            switch (index)
            {
                case 0:
                    relationship = "ConceptuallyRelatedTo";
                    break;
                case 1:
                    relationship = "ThematicKLine";
                    break;
                case 2:
                    relationship = "SuperThematicKLine";
                    break;
                case 3:
                    relationship = "IsA";
                    break;
                case 4:
                    relationship = "PartOf";
                    break;
                case 5:
                    relationship = "PropertyOf";
                    break;
                case 6:
                    relationship = "DefinedAs";
                    break;
                case 7:
                    relationship = "MadeOf";
                    break;
                case 8:
                    relationship = "LocationOf";
                    break;
                case 9:
                    relationship = "SubeventOf";
                    break;
                case 10:
                    relationship = "PrerequisiteEventOf";
                    break;
                case 11:
                    relationship = "First-SubeventOf";
                    break;
                case 12:
                    relationship = "LastSubeventOf";
                    break;
                case 13:
                    relationship = "EffectOf";
                    break;
                case 14:
                    relationship = "DesirousEffectOf";
                    break;
                case 15:
                    relationship = "MotivationOf";
                    break;
                case 16:
                    relationship = "DesireOf";
                    break;
                case 17:
                    relationship = "CapableOfReceivingAction";
                    break;
                case 18:
                    relationship = "UsedFor";
                    break;
                case 19:
                    relationship = "CapableOf";
                    break;
                default:
                    relationship = "IsA"; break;
            }
            return relationship;
        }

        /// <summary>
        /// Returns string of either word1 or word2 in a node depending on the parent word 
        /// </summary>
        /// <param name="parentword">Original word being evaluated.</param>
        /// /// <param name="word1">word1 from a node.</param>
        /// /// <param name="word2">word2 from a node.</param>
        public string get_correctword(string parentword, string word1, string word2)
        {
            string correctword = "";

            try
            {
                if (parentword == word1)
                {
                    correctword = word2;
                }

                if (parentword == word2)
                {
                    correctword = word1;
                }

                if (parentword != word1 && parentword != word2)
                {
                    correctword = word1;
                }
            }
            catch
            {

            }

            return correctword;
        }

        /// <summary>
        /// Returns a value retrieved from a ArrayList.
        /// </summary>
        /// <param name="inList">ArrayList to be searched.</param>
        /// <param name="index">index of ArrayList to retrieve.</param>
        public string GetArrayListValue(ArrayList inList, int index)
        {
            string value = "";
            int count = 0;
            IEnumerator myEnumerator = inList.GetEnumerator();
            while (myEnumerator.MoveNext())
            {
                if (index == count)
                {
                    value = myEnumerator.Current.ToString();
                }

                count = count + 1;
            }

            return value;
        }

        /// <summary>
        /// Returns an object value retrieved from a ArrayList.
        /// </summary>
        /// <param name="inList">ListDictionary to be searched.</param>
        /// <param name="key">key of ListDictionary to retrieve.</param>
        public object GetListDictionaryValue(ListDictionary inList, object key)
        {
            object value = "";

            IEnumerator myEnumerator = inList.GetEnumerator();
            while (myEnumerator.MoveNext())
            {
                if (key == myEnumerator.Current)
                {
                    value = myEnumerator.Current;
                }
            }

            return value;
        }
    }
    #endregion Misc Class

    #region Converts Class
    public class Converts
    {
        #region In Development
        #endregion In Development

        #region Methods Finished/Released

        /// <summary>
        /// Convert IronPython.Runtime.List.ToCodeString() to IronPython.Runtime.List(object, object)
        /// </summary>
        /// <param name="iplistcodestring">IronPython.Runtime.List.ToCodeString()</param>
        /// <returns>Returns an IronPython.Runtime.List(object, object)</returns>
        public static List Convert_CodeStringtoIPList(string iplistcodestring)
        {
            List MyList = new List();
            int i = 0;
            string nextKey = "";
            StringCollection tempSC = new StringCollection();

            //**if begining of List, remove the [
            if (iplistcodestring.StartsWith("[") && i.Equals(0))
            {
                iplistcodestring = iplistcodestring.Replace("[", "");
            }

            foreach (string kv in iplistcodestring.Split(')'))
            {
                string tempstr = "";
                string cur = "";
                cur = kv;
                cur = cur.Trim();

                //**if begining of ICollection and the first item in the sequence, remove the (
                if (cur.StartsWith("(") && i.Equals(0))
                {
                    tempstr = cur.Replace("(", "");
                    tempstr = tempstr.Trim();
                    //Add the first collection
                    tempSC.Add(tempstr);
                }
                else//catch and examine
                {//", ('notebook', 0.00139843782765"
                    //**if begining of ICollection, remove the (
                    if (cur.StartsWith(", ("))
                    {
                        tempstr = cur.Replace(", (", "");
                        tempstr = tempstr.Trim();

                        //Add the next collection
                        tempSC.Add(tempstr);
                    }
                }
                i = i + 1;
            }
            //Finished creating SC, now split each and populate IP.List

            StringEnumerator SCE = tempSC.GetEnumerator();
            while (SCE.MoveNext())
            {
                string[] key_value = SCE.Current.Split(',');
                Object[] okey_value = new Object[key_value.Length];
                //Remove the first ' and last '
                key_value[0] = key_value[0].Remove(0, 1);
                okey_value[0] = (Object)key_value[0].Remove(key_value[0].Length - 1, 1);
                //clean up second value
                okey_value[1] = (Object)key_value[1].Trim();

                MyList.Add(List.MakeList(okey_value));
            }

            return MyList;
        }

        /// <summary>
        /// Returns an ArrayList in string format (with ending "\r\n")  
        /// </summary>
        /// <param name="inList">Incoming ArrayList.</param>
        public static string Convert_ArrayListtoString(ArrayList inList)
        {
            string stringList = "";

            IEnumerator myEnumerator = inList.GetEnumerator();
            while (myEnumerator.MoveNext())
                stringList += myEnumerator.Current.ToString() + "\r\n";

            return stringList;
        }

        /// <summary>
        /// Returns a List in string format  
        /// </summary>
        /// <param name="StringColin">Incoming StringCollection.</param>
        public static ArrayList Convert_StringCollectiontoArrayList(StringCollection StringColin)
        {
            ArrayList newArrayList = new ArrayList();

            StringEnumerator myEnumerator = StringColin.GetEnumerator();
            while (myEnumerator.MoveNext())
                newArrayList.Add(myEnumerator.Current.ToString());

            return newArrayList;
        }

        /// <summary>
        /// Returns a List in string format  
        /// </summary>
        /// <param name="ArrayListin">Incoming ArrayList.</param>
        public static StringCollection Convert_ArrayListtoStringCollection(ArrayList ArrayListin)
        {
            StringCollection StringColl = new StringCollection();

            IEnumerator myEnumerator = ArrayListin.GetEnumerator();
            while (myEnumerator.MoveNext())
                StringColl.Add(myEnumerator.Current.ToString());

            return StringColl;
        }

        /// <summary>
        /// Custom MessageBox call. Excepts some random objects from IronPython and converts to string.
        /// </summary>
        /// <param name="inobject">Output object from IronPython.</param>
        public static void MessageBoxIronPy(Object inobject)
        {
            Type itstype = inobject.GetType();

            switch (itstype.FullName)
            {
                case "IronPython.Runtime.Tuple":
                    Tuple IPTuple = new Tuple((Tuple)inobject);
                    MessageBox.Show(IPTuple.ToString());
                    break;
                case "IronPython.Runtime.Dict":
                    Dict IPDict = new Dict();
                    IPDict = (Dict)inobject;
                    MessageBox.Show(IPDict.ToString());
                    break;
                case "IronPython.Runtime.List":
                    List IPList = new List();
                    IPList = (List)inobject;
                    MessageBox.Show(IPList.ToCodeString());
                    break;
                case "System.String":
                    MessageBox.Show(inobject.ToString());
                    break;
                case "System.Int32":
                    MessageBox.Show(Convert.ToString(inobject));
                    break;
                case "System.Collections.Specialized.StringCollection":
                    StringCollection IPSC = new StringCollection();
                    IPSC = (StringCollection)inobject;
                    StringEnumerator SCE = IPSC.GetEnumerator();
                    string output = "";
                    while (SCE.MoveNext())
                        output += SCE.Current.ToString();
                    MessageBox.Show(output);
                    break;
                default:
                    MessageBox.Show(inobject.GetType().ToString() + " not yet implemented.");
                    break;
                    
            }
        }

        /// <summary>
        /// Convert an IronPython.Runtime.Dict.ToCodeString() object into a Dict
        /// </summary>
        /// <param name="dictcodestring">IronPython.Runtime.Dict.ToCodeString() object</param>
        /// <returns>Returns an IronPython.Runtime.Dict</returns>
        public static Dict Convert_StringtoDict(string dictcodestring)
        {
            Dict myDict = new Dict();
            int i = 0;
            string nextKey = "";

            StringCollection tempSC = new StringCollection();
            foreach (string kv in dictcodestring.Split(':'))
            {
                string tempstr = "";
                string cur = "";
                cur = kv;
                cur = cur.Trim();

                //**if begining of Dict, remove the {
                if (cur.StartsWith("{") && i.Equals(0))
                {
                    tempstr = cur.Replace("{", "");
                    tempstr = tempstr.Trim();

                    //Add the first Key
                    tempSC.Add(tempstr);
                }
                /* else
                 {
                     MessageBox.Show("Error reading Dict string. Could not find starting '{'");
                     return null;
                 }*/

                //**if there is a nextKey, add to Dict
                //or if no next

                //**if '[' found then get its value [x,x...], may have some at end
                if (cur.StartsWith("["))
                {

                    string Value = "";

                    tempstr = cur.Replace("[", "");
                    tempstr = tempstr.Trim();
                    if (tempstr.Contains("],"))
                    {
                        int index = 0;
                        index = tempstr.IndexOf("],");
                        Value = tempstr.Substring(0, index);
                        nextKey = tempstr.Substring(index, tempstr.Length - Value.Length);
                        nextKey = nextKey.Replace("],", "").Trim();

                    }

                    //Add this Value to the last Key
                    myDict.Add(tempSC[i - 1], Value);
                    if (!nextKey.Equals(""))
                    {
                        myDict.Add(nextKey, null);
                    }
                }

                i = i + 1;
            }


            //IEnumerator myEnumerator = inList.GetEnumerator();
            //while (myEnumerator.MoveNext())
            //    stringList += myEnumerator.Current.ToString() + "\r\n";

            return myDict;
        }
        #endregion
    }
    #endregion Converts Class

    #region Monty
    namespace Monty
    {
        public class MontyLingua
        {
            #region Monty Notes:
            /*
         * The following ConceptNet 2.1 MontyLingua methods are not yet added 
         * to the CNU Library but may be called by using PythonEngine.Execute, etc
            def generate_summary(self,vsoos)
            def generate_sentence(self,vsoo,sentence_type='declaration',tense='past',s_dtnum=('',1),o1_dtnum=('',1),o2_dtnum=('',1),o3_dtnum=('',1)):
            def pp_info(self,extracted_infos):
            def tokenize(self,sentence,expand_contractions_p=1):
            def tag_tokenized(self,tokenized_text):
            def strip_tags(self,tagged_or_chunked_text):
            def parse_pred_arg(self,pp):
            def chunk_tagged(self,tagged_text):
            def chunk_lemmatised(self,lemmatised_text):
            def lemmatise_tagged(self,tagged_text):
            def extract_info(self,chunked_text):
             * 
             * MontyExtractor.py...
             * def jist_verb_chunk(self,verbchunk):
         */
            #endregion Monty Notes:

            #region tested and finished 7-24-06
            /// <summary>
            /// Similar to jist() except output is simpler returns a list (document-level)
            /// of lists (sentence-level) of lisp-style predicate argument structures
            /// - each structure should look something like this:
            /// - ("verb" "subject" "obj1" "obj2" ... )
            /// - words are all lemmatised, and determiners and modals are stripped out
            /// - obj's can be direct or indirect, but not subordinate clauses for now.
            /// </summary>
            /// <param name="text">Document-level text</param>
            /// <returns>IronPython List of document level IronPython Lists</returns>
            public static List jist_predicates(string text)
            {
                try
                {
                    CNDB.cn_pe.Globals["text"] = text;
                    CNDB.cn_pe.ExecuteToConsole("r={}");
                    CNDB.cn_pe.ExecuteToConsole("r=c.nltools.m.jist_predicates(text)");

                    return (List)CNDB.cn_pe.Globals["r"];

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), ex.Message);
                    //return ex.Message;
                    return List.MakeEmptyList(4);
                }
            }

            /// <summary>
            /// Digest of each sentence.
            /// </summary>
            /// <param name="text">Document-level text</param>
            /// <returns>IronPython List of Dict values with information digests of each sentence</returns>
            public static List jist(string text)
            {
                try
                {
                    CNDB.cn_pe.Globals["text"] = text;
                    CNDB.cn_pe.ExecuteToConsole("r={}");
                    CNDB.cn_pe.ExecuteToConsole("r=c.nltools.m.jist(text)");

                    return (List)CNDB.cn_pe.Globals["r"];

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), ex.Message);
                    //return ex.Message;
                    return List.MakeEmptyList(4);
                }
            }

            /// <summary>
            /// Seperate paragraphs from document-level text.
            /// </summary>
            /// <param name="text">Document-level text</param>
            /// <returns>IronPython List of paragraph segments</returns>
            public static List split_paragraphs(string text)
            {
                try
                {
                    CNDB.cn_pe.Globals["text"] = text;
                    CNDB.cn_pe.ExecuteToConsole("r={}");
                    CNDB.cn_pe.ExecuteToConsole("r=c.nltools.m.split_paragraphs(text)");

                    return (List)CNDB.cn_pe.Globals["r"];

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), ex.Message);
                    //return ex.Message;
                    return List.MakeEmptyList(4);
                }
            }

            /// <summary>
            /// Seperate sentences from document-level text. 
            /// </summary>
            /// <param name="text">Document-level text</param>
            /// <returns>IronPython List of sentence segments</returns>
            public static List split_sentences(string text)
            {
                try
                {
                    CNDB.cn_pe.Globals["text"] = text;
                    CNDB.cn_pe.ExecuteToConsole("r={}");
                    CNDB.cn_pe.ExecuteToConsole("r=c.nltools.m.split_sentences(text)");

                    return (List)CNDB.cn_pe.Globals["r"];

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), ex.Message);
                    //return ex.Message;
                    return List.MakeEmptyList(4);
                }
            }
            #endregion tested and finished 7-24-06
        }
    }
    #endregion Monty

}
