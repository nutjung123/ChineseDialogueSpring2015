namespace ConceptNetUtils
{
    namespace Forms
    {
        partial class PersonalizedFileForm
        {
            /// <summary>
            /// Required designer variable.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary>
            /// Clean up any resources being used.
            /// </summary>
            /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

            #region Windows Form Designer generated code

            /// <summary>
            /// Required method for Designer support - do not modify
            /// the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
                this.btAdd = new System.Windows.Forms.Button();
                this.tbComplement = new System.Windows.Forms.TextBox();
                this.groupBox2 = new System.Windows.Forms.GroupBox();
                this.tbWord1 = new System.Windows.Forms.TextBox();
                this.cbRelationshipTypes = new System.Windows.Forms.ComboBox();
                this.btClose = new System.Windows.Forms.Button();
                this.btBrowseFile1 = new System.Windows.Forms.Button();
                this.chkbFile1 = new System.Windows.Forms.CheckBox();
                this.groupBox1 = new System.Windows.Forms.GroupBox();
                this.tbFilename = new System.Windows.Forms.TextBox();
                this.chkNewFile = new System.Windows.Forms.CheckBox();
                this.txtDisplay = new System.Windows.Forms.TextBox();
                this.label1 = new System.Windows.Forms.Label();
                this.groupBox2.SuspendLayout();
                this.groupBox1.SuspendLayout();
                this.SuspendLayout();
                // 
                // btAdd
                // 
                this.btAdd.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.btAdd.Location = new System.Drawing.Point(199, 110);
                this.btAdd.Name = "btAdd";
                this.btAdd.Size = new System.Drawing.Size(75, 23);
                this.btAdd.TabIndex = 12;
                this.btAdd.Text = "Add";
                this.btAdd.UseVisualStyleBackColor = true;
                this.btAdd.Click += new System.EventHandler(this.btAdd_Click);
                // 
                // tbComplement
                // 
                this.tbComplement.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.tbComplement.Location = new System.Drawing.Point(8, 81);
                this.tbComplement.Name = "tbComplement";
                this.tbComplement.Size = new System.Drawing.Size(456, 23);
                this.tbComplement.TabIndex = 12;
                // 
                // groupBox2
                // 
                this.groupBox2.Controls.Add(this.tbWord1);
                this.groupBox2.Controls.Add(this.btAdd);
                this.groupBox2.Controls.Add(this.tbComplement);
                this.groupBox2.Controls.Add(this.cbRelationshipTypes);
                this.groupBox2.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.groupBox2.Location = new System.Drawing.Point(14, 114);
                this.groupBox2.Name = "groupBox2";
                this.groupBox2.Size = new System.Drawing.Size(473, 142);
                this.groupBox2.TabIndex = 12;
                this.groupBox2.TabStop = false;
                this.groupBox2.Text = "Add information to a personal predicate text file...";
                // 
                // tbWord1
                // 
                this.tbWord1.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.tbWord1.Location = new System.Drawing.Point(8, 22);
                this.tbWord1.Name = "tbWord1";
                this.tbWord1.Size = new System.Drawing.Size(456, 23);
                this.tbWord1.TabIndex = 13;
                // 
                // cbRelationshipTypes
                // 
                this.cbRelationshipTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
                this.cbRelationshipTypes.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.cbRelationshipTypes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
                this.cbRelationshipTypes.Items.AddRange(new object[] {
            "K-Lines: ConceptuallyRelatedTo",
            "K-Lines: ThematicKLine",
            "K-Lines: SuperThematicKLine",
            "All K-Lines",
            "Things: IsA",
            "Things: PartOf",
            "Things: PropertyOf",
            "Things: DefinedAs",
            "Things: MadeOf",
            "All Things",
            "Spatial: LocationOf",
            "Events: SubeventOf",
            "Events: PrerequisiteEventOf",
            "Events: First-SubeventOf",
            "Events: LastSubeventOf",
            "All Events",
            "Causal: EffectOf",
            "Causal: DesirousEffectOf",
            "All Causal",
            "Affective: MotivationOf",
            "Affective: DesireOf",
            "All Affective",
            "Functional: CapableOfReceivingAction",
            "Functional: UsedFor",
            "All Functional",
            "Agents: CapableOf",
            "All (Returns all results with word)"});
                this.cbRelationshipTypes.Location = new System.Drawing.Point(104, 51);
                this.cbRelationshipTypes.Name = "cbRelationshipTypes";
                this.cbRelationshipTypes.RightToLeft = System.Windows.Forms.RightToLeft.No;
                this.cbRelationshipTypes.Size = new System.Drawing.Size(264, 24);
                this.cbRelationshipTypes.TabIndex = 10;
                // 
                // btClose
                // 
                this.btClose.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.btClose.Location = new System.Drawing.Point(206, 449);
                this.btClose.Name = "btClose";
                this.btClose.Size = new System.Drawing.Size(75, 23);
                this.btClose.TabIndex = 14;
                this.btClose.Text = "Close";
                this.btClose.UseVisualStyleBackColor = true;
                this.btClose.Click += new System.EventHandler(this.btClose_Click);
                // 
                // btBrowseFile1
                // 
                this.btBrowseFile1.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.btBrowseFile1.Location = new System.Drawing.Point(39, 19);
                this.btBrowseFile1.Name = "btBrowseFile1";
                this.btBrowseFile1.Size = new System.Drawing.Size(80, 23);
                this.btBrowseFile1.TabIndex = 19;
                this.btBrowseFile1.Text = "Browse...";
                this.btBrowseFile1.Click += new System.EventHandler(this.btBrowseFile1_Click);
                // 
                // chkbFile1
                // 
                this.chkbFile1.AutoCheck = false;
                this.chkbFile1.Checked = true;
                this.chkbFile1.CheckState = System.Windows.Forms.CheckState.Checked;
                this.chkbFile1.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.chkbFile1.Location = new System.Drawing.Point(6, 19);
                this.chkbFile1.Name = "chkbFile1";
                this.chkbFile1.Size = new System.Drawing.Size(27, 24);
                this.chkbFile1.TabIndex = 18;
                this.chkbFile1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
                this.chkbFile1.Click += new System.EventHandler(this.chkbFile1_Click);
                // 
                // groupBox1
                // 
                this.groupBox1.Controls.Add(this.tbFilename);
                this.groupBox1.Controls.Add(this.chkNewFile);
                this.groupBox1.Controls.Add(this.btBrowseFile1);
                this.groupBox1.Controls.Add(this.chkbFile1);
                this.groupBox1.Location = new System.Drawing.Point(14, 12);
                this.groupBox1.Name = "groupBox1";
                this.groupBox1.Size = new System.Drawing.Size(473, 86);
                this.groupBox1.TabIndex = 20;
                this.groupBox1.TabStop = false;
                this.groupBox1.Text = "File Information";
                // 
                // tbFilename
                // 
                this.tbFilename.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.tbFilename.Location = new System.Drawing.Point(8, 49);
                this.tbFilename.Name = "tbFilename";
                this.tbFilename.Size = new System.Drawing.Size(454, 23);
                this.tbFilename.TabIndex = 13;
                this.tbFilename.Leave += new System.EventHandler(this.tbFilename_Leave);
                this.tbFilename.TextChanged += new System.EventHandler(this.tbFilename_TextChanged);
                // 
                // chkNewFile
                // 
                this.chkNewFile.AutoCheck = false;
                this.chkNewFile.Checked = true;
                this.chkNewFile.CheckState = System.Windows.Forms.CheckState.Checked;
                this.chkNewFile.Font = new System.Drawing.Font("Verdana", 9.75F);
                this.chkNewFile.Location = new System.Drawing.Point(250, 18);
                this.chkNewFile.Name = "chkNewFile";
                this.chkNewFile.Size = new System.Drawing.Size(195, 24);
                this.chkNewFile.TabIndex = 20;
                this.chkNewFile.Text = "Create New File Named:";
                this.chkNewFile.Click += new System.EventHandler(this.chkNewFile_Click);
                // 
                // txtDisplay
                // 
                this.txtDisplay.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                this.txtDisplay.Location = new System.Drawing.Point(14, 262);
                this.txtDisplay.Multiline = true;
                this.txtDisplay.Name = "txtDisplay";
                this.txtDisplay.ReadOnly = true;
                this.txtDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
                this.txtDisplay.Size = new System.Drawing.Size(473, 156);
                this.txtDisplay.TabIndex = 21;
                // 
                // label1
                // 
                this.label1.AutoSize = true;
                this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                this.label1.Location = new System.Drawing.Point(93, 421);
                this.label1.Name = "label1";
                this.label1.Size = new System.Drawing.Size(315, 13);
                this.label1.TabIndex = 22;
                this.label1.Text = "Remember to point  the new file(s) using the settings.";
                // 
                // PersonalizedFileForm
                // 
                this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
                this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
                this.ClientSize = new System.Drawing.Size(500, 484);
                this.Controls.Add(this.label1);
                this.Controls.Add(this.btClose);
                this.Controls.Add(this.txtDisplay);
                this.Controls.Add(this.groupBox1);
                this.Controls.Add(this.groupBox2);
                this.Name = "PersonalizedFileForm";
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
                this.Text = "Create a Personal Common Sense Text File";
                this.Load += new System.EventHandler(this.PersonalizedFileForm_Load);
                this.groupBox2.ResumeLayout(false);
                this.groupBox2.PerformLayout();
                this.groupBox1.ResumeLayout(false);
                this.groupBox1.PerformLayout();
                this.ResumeLayout(false);
                this.PerformLayout();

            }

            #endregion

            private System.Windows.Forms.Button btAdd;
            private System.Windows.Forms.TextBox tbComplement;
            private System.Windows.Forms.GroupBox groupBox2;
            private System.Windows.Forms.ComboBox cbRelationshipTypes;
            private System.Windows.Forms.Button btBrowseFile1;
            private System.Windows.Forms.CheckBox chkbFile1;
            private System.Windows.Forms.GroupBox groupBox1;
            private System.Windows.Forms.CheckBox chkNewFile;
            private System.Windows.Forms.TextBox tbWord1;
            private System.Windows.Forms.TextBox tbFilename;
            private System.Windows.Forms.TextBox txtDisplay;
            private System.Windows.Forms.Button btClose;
            private System.Windows.Forms.Label label1;

        }
    }
}